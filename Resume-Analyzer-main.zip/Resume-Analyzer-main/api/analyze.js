// ---------------------------------------------------------------------------
// POST /api/analyze — multipart/form-data resume analysis endpoint.
//   fields: resume (file: PDF/DOCX/TXT, <= 5MB), job_description (text, optional),
//           demo ('true'|'false', optional)
// Returns the full structured analysis JSON. Files are processed in memory and
// never persisted. Mirrors backend/app/routers/analyze.py (FastAPI).
// ---------------------------------------------------------------------------

import Busboy from 'busboy';
import { extractTextFromFile, fileExtension, ParseError } from './lib/parse.js';
import { analyzeResumeText } from './lib/analyzer.js';
import { normalizeRaw, wordCount } from './lib/text.js';

export const config = {
  api: { bodyParser: false },
  maxDuration: 30,
};

const MAX_SIZE = 5 * 1024 * 1024; // 5 MB
const ALLOWED = new Set(['pdf', 'docx', 'txt']);

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function parseMultipart(req) {
  return new Promise((resolve, reject) => {
    let bb;
    try {
      bb = Busboy({ headers: req.headers, limits: { fileSize: MAX_SIZE, files: 1, fields: 12 } });
    } catch (err) {
      reject(err);
      return;
    }
    const fields = {};
    let fileBuf = null;
    let fileName = '';
    let truncated = false;

    bb.on('field', (name, val) => {
      fields[name] = String(val).slice(0, 60000);
    });
    bb.on('file', (name, file, info) => {
      fileName = (info && info.filename) || 'resume.txt';
      const chunks = [];
      file.on('data', (d) => chunks.push(d));
      file.on('limit', () => {
        truncated = true;
      });
      file.on('end', () => {
        fileBuf = Buffer.concat(chunks);
      });
    });
    bb.on('error', reject);
    bb.on('finish', () => resolve({ fields, fileBuf, fileName, truncated }));
    req.pipe(bb);
  });
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed. POST a multipart/form-data body with a `resume` file field and an optional `job_description` text field.' });
  }

  try {
    const contentType = req.headers['content-type'] || '';
    if (!contentType.includes('multipart/form-data')) {
      return res.status(400).json({ error: 'Expected multipart/form-data with a `resume` file field.' });
    }

    const { fields, fileBuf, fileName, truncated } = await parseMultipart(req);

    if (truncated) return res.status(413).json({ error: 'File exceeds the 5 MB limit. Please upload a smaller resume.' });
    if (!fileName || !fileBuf) return res.status(400).json({ error: 'No resume file was provided. Attach a PDF, DOCX or TXT file in the `resume` field.' });

    const ext = fileExtension(fileName);
    if (!ALLOWED.has(ext)) {
      return res.status(415).json({ error: `Unsupported file type ".${ext || '?'}". Please upload a PDF, DOCX or TXT resume.` });
    }
    if (fileBuf.length === 0) return res.status(400).json({ error: 'The uploaded file is empty.' });

    let text;
    try {
      text = normalizeRaw(await extractTextFromFile(fileName, fileBuf));
    } catch (err) {
      if (err instanceof ParseError) return res.status(err.status).json({ error: err.message });
      throw err;
    }

    if (wordCount(text) < 25) {
      return res.status(422).json({
        error: 'Not enough readable text was found in this file (minimum ~25 words). If this is a PDF, it may be a scanned image — try a text-based PDF, DOCX or TXT export.',
      });
    }

    const jd = String(fields.job_description || '');
    const result = analyzeResumeText({
      resumeText: text,
      jdText: jd,
      fileName,
      fileType: ext,
      demo: String(fields.demo || '') === 'true',
    });

    return res.status(200).json(result);
  } catch (err) {
    console.error('[analyze] failed:', err);
    return res.status(500).json({ error: 'Analysis failed due to an internal error. Please try again, or use a different file format.' });
  }
}
