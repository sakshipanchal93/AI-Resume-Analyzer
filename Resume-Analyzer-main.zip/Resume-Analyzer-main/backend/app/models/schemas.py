"""Pydantic response models for the Analyze API."""

from typing import Literal

from pydantic import BaseModel


class SectionInfo(BaseModel):
    key: str
    label: str
    status: Literal['present', 'attention', 'missing']
    words: int
    detail: str


class Recommendation(BaseModel):
    title: str
    detail: str
    priority: Literal['high', 'medium', 'low']


class RadarPoint(BaseModel):
    dimension: str
    resume: int
    target: int


class SkillCategoryCount(BaseModel):
    category: str
    count: int


class Charts(BaseModel):
    radar: list[RadarPoint]
    skill_distribution: list[SkillCategoryCount]


class JdKeyword(BaseModel):
    term: str
    count: int
    present: bool


class SkillRatio(BaseModel):
    matched: int
    required: int


class WeightInfo(BaseModel):
    label: str
    value: int


class Metrics(BaseModel):
    word_count: int
    bullets: int
    quantified_achievements: int
    action_verb_count: int
    action_verbs_found: list[str]
    date_ranges: int


class Meta(BaseModel):
    file_name: str
    file_type: str
    word_count: int
    mode: Literal['job_match', 'quality']
    demo: bool
    processing_ms: int
    disclaimer: str


class AnalysisResponse(BaseModel):
    overall_score: int
    resume_quality_score: int
    keyword_match_score: int | None
    skills_match_score: int | None
    similarity_score: int | None
    skills: list[str]
    jd_skills: list[str]
    matched_skills: list[str]
    missing_skills: list[str]
    skill_match_ratio: SkillRatio | None
    keywords: list[str]
    missing_keywords: list[str]
    jd_keywords: list[JdKeyword]
    resume_top_keywords: list[str]
    sections: list[SectionInfo]
    completeness_score: int
    metrics: Metrics
    recommendations: list[Recommendation]
    summary: str
    charts: Charts
    weights: list[WeightInfo]
    meta: Meta
