"""AlignAI — AI Resume Analyzer (FastAPI backend).

Run locally:
    cd backend
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8000

The React frontend reads VITE_API_URL (see .env.example at the repo root) and
POSTs multipart/form-data to /api/analyze.
"""

import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import analyze

app = FastAPI(
    title="AlignAI Resume Analyzer API",
    description="NLP-powered resume parsing, skill extraction and job-match scoring.",
    version="1.0.0",
)

origins = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in origins if o.strip()] or ["*"],
    allow_credentials=False,
    allow_methods=["POST", "GET", "OPTIONS"],
    allow_headers=["*"],
)

app.include_router(analyze.router, prefix="/api")


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "service": "alignai-resume-analyzer"}
