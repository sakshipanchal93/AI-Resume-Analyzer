"""Extensible skill dictionary + extraction. Mirrors api/lib/skills.js.

To extend: append an entry to SKILL_DICTIONARY — nothing else changes.
"""

from .text import canonicalize

SKILL_DICTIONARY = [
    # Programming Languages
    {'name': 'Python', 'category': 'Programming Languages', 'aliases': ['python']},
    {'name': 'Java', 'category': 'Programming Languages', 'aliases': ['java']},
    {'name': 'C++', 'category': 'Programming Languages', 'aliases': ['c++', 'cpp', 'cplusplus']},
    {'name': 'C#', 'category': 'Programming Languages', 'aliases': ['c#', 'csharp']},
    {'name': 'JavaScript', 'category': 'Programming Languages', 'aliases': ['javascript', 'es6', 'es2020']},
    {'name': 'TypeScript', 'category': 'Programming Languages', 'aliases': ['typescript']},
    {'name': 'Go', 'category': 'Programming Languages', 'aliases': ['golang']},
    {'name': 'Ruby', 'category': 'Programming Languages', 'aliases': ['ruby', 'ruby on rails']},
    {'name': 'SQL', 'category': 'Programming Languages', 'aliases': ['sql']},
    # Frontend
    {'name': 'React', 'category': 'Frontend', 'aliases': ['react', 'reactjs', 'react.js']},
    {'name': 'Angular', 'category': 'Frontend', 'aliases': ['angular', 'angularjs']},
    {'name': 'Vue.js', 'category': 'Frontend', 'aliases': ['vue', 'vuejs', 'vue.js']},
    {'name': 'Next.js', 'category': 'Frontend', 'aliases': ['nextjs', 'next.js']},
    {'name': 'HTML', 'category': 'Frontend', 'aliases': ['html', 'html5']},
    {'name': 'CSS', 'category': 'Frontend', 'aliases': ['css', 'css3']},
    {'name': 'Tailwind CSS', 'category': 'Frontend', 'aliases': ['tailwind', 'tailwindcss', 'tailwind css']},
    {'name': 'Redux', 'category': 'Frontend', 'aliases': ['redux']},
    {'name': 'Sass', 'category': 'Frontend', 'aliases': ['sass', 'scss']},
    # Backend
    {'name': 'Node.js', 'category': 'Backend', 'aliases': ['node', 'nodejs', 'node.js']},
    {'name': 'Express', 'category': 'Backend', 'aliases': ['express', 'expressjs', 'express.js']},
    {'name': 'FastAPI', 'category': 'Backend', 'aliases': ['fastapi', 'fast api']},
    {'name': 'Flask', 'category': 'Backend', 'aliases': ['flask']},
    {'name': 'Django', 'category': 'Backend', 'aliases': ['django']},
    {'name': 'Spring Boot', 'category': 'Backend', 'aliases': ['spring boot', 'springboot']},
    {'name': 'GraphQL', 'category': 'Backend', 'aliases': ['graphql']},
    {'name': 'REST API', 'category': 'Backend', 'aliases': ['rest api', 'rest apis', 'restful', 'restapi', 'rest']},
    {'name': 'Microservices', 'category': 'Backend', 'aliases': ['microservices', 'micro services', 'microservice']},
    # Databases
    {'name': 'MySQL', 'category': 'Databases', 'aliases': ['mysql']},
    {'name': 'PostgreSQL', 'category': 'Databases', 'aliases': ['postgresql', 'postgres']},
    {'name': 'MongoDB', 'category': 'Databases', 'aliases': ['mongodb', 'mongo db']},
    {'name': 'SQLite', 'category': 'Databases', 'aliases': ['sqlite']},
    {'name': 'Redis', 'category': 'Databases', 'aliases': ['redis']},
    {'name': 'Kafka', 'category': 'Databases', 'aliases': ['kafka', 'apache kafka']},
    # Data & ML
    {'name': 'Machine Learning', 'category': 'Data & ML', 'aliases': ['machinelearning', 'machine learning', 'ml models']},
    {'name': 'Deep Learning', 'category': 'Data & ML', 'aliases': ['deeplearning', 'deep learning']},
    {'name': 'NLP', 'category': 'Data & ML', 'aliases': ['nlp', 'natural language processing']},
    {'name': 'TensorFlow', 'category': 'Data & ML', 'aliases': ['tensorflow', 'tensor flow']},
    {'name': 'Keras', 'category': 'Data & ML', 'aliases': ['keras']},
    {'name': 'Scikit-Learn', 'category': 'Data & ML', 'aliases': ['scikit-learn', 'scikit learn', 'scikitlearn', 'sklearn']},
    {'name': 'XGBoost', 'category': 'Data & ML', 'aliases': ['xgboost', 'xg boost']},
    {'name': 'Pandas', 'category': 'Data & ML', 'aliases': ['pandas']},
    {'name': 'NumPy', 'category': 'Data & ML', 'aliases': ['numpy']},
    {'name': 'PyTorch', 'category': 'Data & ML', 'aliases': ['pytorch', 'py torch']},
    {'name': 'Power BI', 'category': 'Data & ML', 'aliases': ['power bi', 'powerbi']},
    {'name': 'Excel', 'category': 'Data & ML', 'aliases': ['excel', 'microsoft excel', 'ms excel']},
    {'name': 'Tableau', 'category': 'Data & ML', 'aliases': ['tableau']},
    {'name': 'Data Analysis', 'category': 'Data & ML', 'aliases': ['dataanalysis', 'data analysis', 'data analytics']},
    {'name': 'Statistics', 'category': 'Data & ML', 'aliases': ['statistics', 'statistical analysis']},
    {'name': 'ETL', 'category': 'Data & ML', 'aliases': ['etl', 'etl pipelines']},
    # Cloud & DevOps
    {'name': 'AWS', 'category': 'Cloud & DevOps', 'aliases': ['aws', 'amazon web services', 'ec2', 's3']},
    {'name': 'Azure', 'category': 'Cloud & DevOps', 'aliases': ['azure', 'microsoft azure']},
    {'name': 'Google Cloud', 'category': 'Cloud & DevOps', 'aliases': ['gcp', 'google cloud', 'google cloud platform']},
    {'name': 'Docker', 'category': 'Cloud & DevOps', 'aliases': ['docker', 'containerized', 'containerization']},
    {'name': 'Kubernetes', 'category': 'Cloud & DevOps', 'aliases': ['kubernetes', 'k8s']},
    {'name': 'CI/CD', 'category': 'Cloud & DevOps', 'aliases': ['ci/cd', 'cicd', 'continuous integration', 'continuous delivery']},
    {'name': 'Linux', 'category': 'Cloud & DevOps', 'aliases': ['linux', 'ubuntu']},
    {'name': 'Git', 'category': 'Cloud & DevOps', 'aliases': ['git']},
    {'name': 'GitHub', 'category': 'Cloud & DevOps', 'aliases': ['github', 'github actions']},
    {'name': 'GitLab', 'category': 'Cloud & DevOps', 'aliases': ['gitlab']},
    {'name': 'Jenkins', 'category': 'Cloud & DevOps', 'aliases': ['jenkins']},
    {'name': 'Terraform', 'category': 'Cloud & DevOps', 'aliases': ['terraform']},
    # Practices
    {'name': 'Agile', 'category': 'Practices', 'aliases': ['agile', 'agile methodology']},
    {'name': 'Scrum', 'category': 'Practices', 'aliases': ['scrum', 'kanban']},
    {'name': 'Testing', 'category': 'Practices', 'aliases': ['unittesting', 'unit testing', 'unit tests', 'pytest', 'jest', 'selenium', 'tdd']},
    {'name': 'OOP', 'category': 'Practices', 'aliases': ['oop', 'object oriented programming', 'object-oriented programming']},
    {'name': 'Data Structures', 'category': 'Practices', 'aliases': ['datastructures', 'data structures']},
    {'name': 'Algorithms', 'category': 'Practices', 'aliases': ['algorithms', 'algorithm design']},
    {'name': 'System Design', 'category': 'Practices', 'aliases': ['systemdesign', 'system design', 'distributed systems']},
    {'name': 'Problem Solving', 'category': 'Practices', 'aliases': ['problemsolving', 'problem solving', 'analytical skills']},
    {'name': 'Communication', 'category': 'Practices', 'aliases': ['communication skills', 'communication', 'written communication']},
]

_INDEX = [
    {'name': s['name'], 'category': s['category'], 'aliases': [canonicalize(a) for a in s['aliases']]}
    for s in SKILL_DICTIONARY
]

SKILL_TOKENS = {
    tok
    for s in _INDEX
    for a in s['aliases']
    for tok in a.split()
    if tok
}


def extract_skills(text: str) -> list[dict]:
    """Return [{'name', 'category'}] for every skill found in `text`."""
    hay = canonicalize(text)
    return [
        {'name': s['name'], 'category': s['category']}
        for s in _INDEX
        if any(a in hay for a in s['aliases'])
    ]
