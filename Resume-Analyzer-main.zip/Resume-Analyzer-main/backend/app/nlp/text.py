"""Text normalization, canonicalization and tokenization.
Mirrors api/lib/text.js in the Node serverless deployment.
"""

import re

STOPWORDS = {
    'a', 'an', 'the', 'and', 'or', 'but', 'if', 'then', 'else', 'when', 'at', 'by', 'for', 'with',
    'about', 'against', 'between', 'into', 'through', 'during', 'before', 'after', 'above',
    'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again',
    'further', 'once', 'here', 'there', 'all', 'any', 'both', 'each', 'few', 'more', 'most',
    'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too',
    'very', 'can', 'will', 'just', 'should', 'now', 'of', 'is', 'am', 'are', 'was', 'were',
    'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing',
    'would', 'could', 'shall', 'may', 'might', 'must', 'i', 'me', 'my', 'we', 'our', 'you',
    'your', 'he', 'him', 'his', 'she', 'her', 'it', 'its', 'they', 'them', 'their', 'this',
    'that', 'these', 'those', 'as', 'us', 'who', 'whom', 'what', 'which', 'while', 'also',
    'per', 'via', 'etc', 'ie', 'eg', 'vs', 'within', 'across', 'towards', 'toward', 'among',
}

JD_NOISE = {
    'experience', 'years', 'year', 'team', 'work', 'working', 'ability', 'strong', 'knowledge',
    'skill', 'skills', 'plus', 'including', 'include', 'related', 'preferred', 'required',
    'requirements', 'responsibilities', 'responsible', 'qualifications', 'qualified',
    'ideal', 'candidate', 'join', 'help', 'looking', 'look', 'familiarity', 'familiar',
    'understanding', 'proficiency', 'proficient', 'proven', 'track', 'record', 'role',
    'company', 'job', 'position', 'opportunity', 'environment', 'etc', 'well', 'good', 'great',
    'new', 'day', 'll', 're', 've', 'don', 'won', 'also', 'must', 'highly', 'passionate',
    'driven', 'collaborate', 'collaboration', 'fast', 'paced', 'dynamic', 'build', 'building',
    'design', 'develop', 'deliver', 'drive', 'ensure', 'support', 'provide', 'using', 'use',
    'used', 'tools', 'technologies', 'technology', 'solutions', 'solution', 'services',
    'business', 'product', 'products', 'engineering', 'engineer', 'software', 'senior',
    'junior', 'lead', 'manager', 'will', 'youll', 'youre', 'best', 'class', 'world', 'deep',
    'hands', 'problems', 'stakeholders', 'customers', 'users', 'growth', 'mission',
}

# Applied BEFORE punctuation stripping so tech tokens survive as single tokens.
CANON_RULES = [
    (re.compile(r'\bc\s*\+\s*\+'), 'cplusplus'),
    (re.compile(r'\bc\s*#'), 'csharp'),
    (re.compile(r'\bci\s*[\/\-\s]?\s*cd\b'), 'cicd'),
    (re.compile(r'\bcontinuous\s+(integration|delivery|deployment)\b'), 'cicd'),
    (re.compile(r'\bnode\s*\.?\s*js\b'), 'nodejs'),
    (re.compile(r'\breact\s*\.?\s*js\b'), 'reactjs'),
    (re.compile(r'\bvue\s*\.?\s*js\b'), 'vuejs'),
    (re.compile(r'\bnext\s*\.?\s*js\b'), 'nextjs'),
    (re.compile(r'\bexpress\s*\.?\s*js\b'), 'expressjs'),
    (re.compile(r'\bangular\s*\.?\s*js\b'), 'angularjs'),
    (re.compile(r'\bscikit[-\s]?learn\b'), 'scikitlearn'),
    (re.compile(r'\bsklearn\b'), 'scikitlearn'),
    (re.compile(r'\bpower\s*bi\b'), 'powerbi'),
    (re.compile(r'\bmongo\s*db\b'), 'mongodb'),
    (re.compile(r'\bpostgres\b'), 'postgresql'),
    (re.compile(r'\bk8s\b'), 'kubernetes'),
    (re.compile(r'\bn\s*\.?\s*l\s*\.?\s*p\b'), 'nlp'),
    (re.compile(r'\bo\s*\.?\s*o\s*\.?\s*p\b'), 'oop'),
    (re.compile(r'\bobject[-\s]oriented\s(programming|design)\b'), 'oop'),
    (re.compile(r'\bgit\s*hub\b'), 'github'),
    (re.compile(r'\bgit\s*lab\b'), 'gitlab'),
    (re.compile(r'\bspring\s*boot\b'), 'springboot'),
    (re.compile(r'\bweb\s*sockets?\b'), 'websockets'),
    (re.compile(r'\bunit[-\s]test(s|ing)?\b'), 'unittesting'),
    (re.compile(r'\bamazon\s+web\s+services\b'), 'aws'),
    (re.compile(r'\bgoogle\s+cloud(\s+platform)?\b'), 'gcp'),
    (re.compile(r'\bmicrosoft\s+azure\b'), 'azure'),
    (re.compile(r'\bnatural\s+language\s+processing\b'), 'nlp'),
    (re.compile(r'\bmachine\s+learning\b'), 'machinelearning'),
    (re.compile(r'\bdeep\s+learning\b'), 'deeplearning'),
    (re.compile(r'\bsystem\s+design\b'), 'systemdesign'),
    (re.compile(r'\bdata\s+structures\b'), 'datastructures'),
    (re.compile(r'\bdata\s+analysis\b'), 'dataanalysis'),
    (re.compile(r'\btest[-\s]driven\s+development\b'), 'tdd'),
    (re.compile(r'\brest\s*ful(\s+apis?)?\b'), 'restapi'),
    (re.compile(r'\brest\s+apis?\b'), 'restapi'),
    (re.compile(r'\bgraph\s*ql\b'), 'graphql'),
    (re.compile(r'\btailwind(\s*css)?\b'), 'tailwind'),
    (re.compile(r'\btensor\s*flow\b'), 'tensorflow'),
    (re.compile(r'\bproblem[-\s]solving\b'), 'problemsolving'),
    (re.compile(r'\bcommunication\s+skills?\b'), 'communication'),
]


def canonicalize(text: str) -> str:
    """Lowercase + canonicalize + strip punctuation. Space-padded for safe
    whole-token `in` matching (' token ' style)."""
    t = f" {str(text or '').lower()} "
    for rule, rep in CANON_RULES:
        t = rule.sub(f' {rep} ', t)
    t = re.sub(r'[^a-z0-9]+', ' ', t)
    return f" {' '.join(t.split())} "


def normalize_raw(text: str) -> str:
    """Display-safe normalization: unicode quotes/dashes/bullets, blank runs."""
    t = str(text or '').replace('\r\n', '\n').replace('\r', '\n')
    for a, b in (('\u2018', "'"), ('\u2019', "'"), ('\u201c', '"'), ('\u201d', '"'),
                 ('\u2013', '-'), ('\u2014', '-'), ('\u2022', '-'), ('\u25cf', '-'),
                 ('\u25aa', '-'), ('\u2023', '-'), ('\u2043', '-')):
        t = t.replace(a, b)
    t = t.replace('\u0000', '')
    t = re.sub(r'[ \t]+', ' ', t)
    t = re.sub(r'\n{3,}', '\n\n', t)
    return t.strip()


def tokenize(text: str) -> list[str]:
    return [
        t for t in canonicalize(text).split()
        if len(t) >= 2 and re.search(r'[a-z]', t) and t not in STOPWORDS
    ]


def stem(term: str) -> str:
    if len(term) > 4 and term.endswith('ies'):
        return term[:-3] + 'y'
    if len(term) > 3 and term.endswith('es') and not term.endswith('ses'):
        return term[:-2]
    if len(term) > 3 and term.endswith('s') and not term.endswith(('ss', 'us', 'is')):
        return term[:-1]
    return term


def word_count(text: str) -> int:
    return len(str(text or '').split())
