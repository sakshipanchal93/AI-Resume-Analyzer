"""Resume section detection. Mirrors api/lib/sections.js."""

import re

SECTION_DEFS = [
    {'key': 'summary', 'label': 'Summary', 'min_words': 15,
     'headings': ['summary', 'professional summary', 'career summary', 'profile',
                  'professional profile', 'objective', 'career objective', 'about me',
                  'executive summary']},
    {'key': 'experience', 'label': 'Experience', 'min_words': 20,
     'headings': ['experience', 'work experience', 'professional experience',
                  'employment history', 'work history', 'career history',
                  'relevant experience', 'professional background']},
    {'key': 'education', 'label': 'Education', 'min_words': 6,
     'headings': ['education', 'academic background', 'academics', 'education and training',
                  'educational qualifications', 'academic qualifications']},
    {'key': 'projects', 'label': 'Projects', 'min_words': 8,
     'headings': ['projects', 'personal projects', 'key projects', 'selected projects',
                  'academic projects', 'side projects', 'notable projects', 'project work']},
    {'key': 'skills', 'label': 'Skills', 'min_words': 4,
     'headings': ['skills', 'technical skills', 'core skills', 'key skills', 'technologies',
                  'tech stack', 'technical competencies', 'core competencies',
                  'areas of expertise', 'skills and technologies']},
    {'key': 'certifications', 'label': 'Certifications', 'min_words': 3,
     'headings': ['certifications', 'certification', 'certificates', 'licenses',
                  'licenses and certifications', 'credentials', 'professional certifications']},
    {'key': 'achievements', 'label': 'Achievements', 'min_words': 4,
     'headings': ['achievements', 'accomplishments', 'awards', 'honors', 'honours',
                  'awards and achievements', 'key achievements', 'recognition']},
]

EMAIL_RE = re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')
PHONE_RE = re.compile(r'(\+?\d[\d\s().\-]{7,}\d)')
LINK_RE = re.compile(r'(linkedin\.com|github\.com|portfolio|https?://)', re.I)


def _looks_like_heading(line: str):
    t = line.strip()
    if not t or len(t) > 44 or re.search(r'[.;!?]$', t):
        return None
    norm = re.sub(r'[^a-z\s&]', ' ', t.lower())
    norm = re.sub(r'\s+', ' ', norm)
    norm = re.sub(r' and | & ', ' and ', norm).strip()
    for d in SECTION_DEFS:
        for h in d['headings']:
            if norm == h or (h in norm and len(norm) <= len(h) + 14):
                return d['key']
    return None


def detect_sections(raw_text: str) -> list[dict]:
    lines = str(raw_text or '').split('\n')
    found: dict[str, int] = {}
    heading_idx: list[int] = []
    for idx, line in enumerate(lines):
        key = _looks_like_heading(line)
        if key and key not in found:
            found[key] = idx
            heading_idx.append(idx)
        elif key:
            heading_idx.append(idx)

    def content_words(idx: int) -> int:
        nxt = next((i for i in heading_idx if i > idx), len(lines))
        return len(' '.join(lines[idx + 1:nxt]).split())

    sections = []

    has_email = bool(EMAIL_RE.search(raw_text))
    has_phone = bool(PHONE_RE.search(raw_text))
    has_link = bool(LINK_RE.search(raw_text))
    signals = int(has_email) + int(has_phone)
    if signals == 2:
        sections.append({'key': 'contact', 'label': 'Contact', 'status': 'present', 'words': 0,
                         'detail': 'Email and phone detected' + (', plus a profile link.' if has_link else '.')})
    elif signals == 1 or (has_link and signals == 0):
        sections.append({'key': 'contact', 'label': 'Contact', 'status': 'attention', 'words': 0,
                         'detail': 'Email found — add a phone number and LinkedIn/profile link.' if has_email
                         else 'Phone found — add a professional email address.'})
    else:
        sections.append({'key': 'contact', 'label': 'Contact', 'status': 'missing', 'words': 0,
                         'detail': 'No email or phone number detected — parsers and recruiters cannot reach this candidate.'})

    for d in SECTION_DEFS:
        if d['key'] not in found:
            sections.append({'key': d['key'], 'label': d['label'], 'status': 'missing', 'words': 0,
                             'detail': f'No "{d["label"]}" section heading was detected.'})
        else:
            words = content_words(found[d['key']])
            present = words >= d['min_words']
            sections.append({'key': d['key'], 'label': d['label'],
                             'status': 'present' if present else 'attention', 'words': words,
                             'detail': f'Detected with {words} words of content.' if present
                             else f'Heading found but only {words} words — expand this section '
                                  f'(aim for {d["min_words"]}+ words).'})
    return sections
