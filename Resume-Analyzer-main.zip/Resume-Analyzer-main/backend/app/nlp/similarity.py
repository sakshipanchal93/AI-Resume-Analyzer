"""TF-IDF + cosine similarity via scikit-learn.

Uses TfidfVectorizer(sublinear_tf=True, smooth_idf=True, norm='l2') over the
pre-tokenized 2-document corpus [resume, job_description] — the same math the
Node implementation (api/lib/similarity.js) reproduces operator-free.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .text import tokenize


def tfidf_cosine(resume_text: str, jd_text: str) -> float:
    docs = [' '.join(tokenize(resume_text)), ' '.join(tokenize(jd_text))]
    if not docs[0] or not docs[1]:
        return 0.0
    vec = TfidfVectorizer(sublinear_tf=True, smooth_idf=True, norm='l2')
    try:
        matrix = vec.fit_transform(docs)
    except ValueError:  # empty vocabulary
        return 0.0
    score = cosine_similarity(matrix[0:1], matrix[1:2])[0][0]
    return float(max(0.0, min(1.0, score)))
