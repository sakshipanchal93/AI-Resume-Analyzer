"""Keyword extraction + found/missing analysis. Mirrors api/lib/keywords.js."""

import math
from collections import Counter

from .skills import SKILL_TOKENS
from .text import JD_NOISE, stem, tokenize


def _rank_terms(tokens: list[str], limit: int) -> list[dict]:
    freq = Counter(
        t for t in tokens if len(t) >= 3 and t not in JD_NOISE and not t.isdigit()
    )
    by_stem: dict[str, dict] = {}
    for term, count in freq.items():
        s = stem(term)
        cur = by_stem.get(s)
        if cur is None or count > cur['count']:
            if cur is None:
                by_stem[s] = {'term': term, 'count': count}
            else:
                by_stem[s] = {'term': term, 'count': count}
        else:
            cur['count'] += count
    scored = [
        {
            'term': e['term'],
            'count': e['count'],
            'score': e['count'] * (1 + math.log(len(e['term']))) * (1.35 if e['term'] in SKILL_TOKENS else 1.0),
        }
        for e in by_stem.values()
    ]
    scored.sort(key=lambda x: x['score'], reverse=True)
    return scored[:limit]


def extract_jd_keywords(jd_text: str, resume_text: str, limit: int = 12) -> list[dict]:
    ranked = _rank_terms(tokenize(jd_text), limit)
    resume_stems = {stem(t) for t in tokenize(resume_text)}
    return [{'term': r['term'], 'count': r['count'], 'present': stem(r['term']) in resume_stems} for r in ranked]


def top_resume_terms(resume_text: str, limit: int = 10) -> list[str]:
    return [r['term'] for r in _rank_terms(tokenize(resume_text), limit)]
