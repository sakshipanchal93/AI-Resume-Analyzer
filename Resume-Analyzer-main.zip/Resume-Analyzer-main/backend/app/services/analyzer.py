"""Analysis orchestration: sections -> skills -> keywords -> TF-IDF similarity
-> weighted scoring -> dynamic recommendations + summary.
Mirrors api/lib/analyzer.js in the Node serverless deployment.
"""

import re
import time

from app.nlp.keywords import extract_jd_keywords, top_resume_terms
from app.nlp.sections import detect_sections
from app.nlp.similarity import tfidf_cosine
from app.nlp.skills import extract_skills
from app.nlp.text import tokenize, word_count

ACTION_VERBS = [
    'developed', 'built', 'led', 'designed', 'implemented', 'improved', 'created',
    'managed', 'launched', 'optimized', 'delivered', 'engineered', 'architected',
    'automated', 'reduced', 'increased', 'collaborated', 'mentored', 'spearheaded',
    'drove', 'shipped', 'scaled', 'migrated', 'refactored', 'deployed', 'founded',
]

QUANT_RE = re.compile(
    r'(\d+(?:\.\d+)?\s?%|\$\s?\d[\d,.]*\s?[kKmMbB]?\b|\b\d+\+?\s?(?:users?|customers?|clients?'
    r'|projects?|teams?|engineers?|developers?|requests?|transactions?|records?|downloads?'
    r'|revenue|sales|hours?|days?|weeks?|months?|years?|members?|applications?|apps|services'
    r'|models?|pipelines?|dashboards?|companies|attendees|employees)\b)',
    re.I,
)
DATE_RANGE_RE = re.compile(r'(?:19|20)\d{2}\s?[-–—]\s?(?:(?:19|20)\d{2}|present|current|now)', re.I)
BULLET_RE = re.compile(r'^\s*[-*•▪◦o]\s+\S')


def _clamp(n: float) -> int:
    return max(0, min(100, round(n)))


def _status_score(section: dict, present=90, attention=60, missing=15) -> int:
    return present if section['status'] == 'present' else attention if section['status'] == 'attention' else missing


def _depth(sections: list[dict], m: dict) -> int:
    by = {s['key']: s for s in sections}
    d = 0
    d += 20 if by['contact']['status'] == 'present' else 10 if by['contact']['status'] == 'attention' else 0
    d += 15 if by['summary']['status'] == 'present' else 8 if by['summary']['status'] == 'attention' else 0
    d += 15 if m['bullets'] >= 4 else 8 if m['bullets'] >= 2 else 0
    d += 20 if m['quantified'] >= 3 else 10 if m['quantified'] >= 1 else 0
    wc = m['word_count']
    d += 15 if 300 <= wc <= 1100 else 8 if (150 <= wc < 300) or (1100 < wc <= 1600) else 0
    d += 15 if m['action_verbs'] >= 5 else 8 if m['action_verbs'] >= 3 else 0
    return d


def _recommendations(c: dict) -> list[dict]:
    sections, mode = c['sections'], c['mode']
    by = {s['key']: s for s in sections}
    recs = []

    missing_secs = [s['label'] for s in sections if s['status'] == 'missing']
    if missing_secs:
        recs.append({'priority': 'high',
                     'title': f"Add the missing {', '.join(missing_secs[:3])} section{'s' if len(missing_secs) > 1 else ''}",
                     'detail': f"Section completeness is {c['completeness']}%. Recruiters and resume parsers expect "
                               f"clear {', '.join(missing_secs)} sections — add a dedicated heading for each one that applies to you."})

    attention = [s['label'] for s in sections if s['status'] == 'attention' and s['key'] != 'contact']
    if attention:
        recs.append({'priority': 'medium',
                     'title': f"Expand your thin {' and '.join(attention[:2])} section{'s' if len(attention) > 1 else ''}",
                     'detail': f"{', '.join(attention)} contain very little content. Add concrete detail — role scope, "
                               'technologies used and outcomes.'})

    if by['contact']['status'] != 'present':
        recs.append({'priority': 'high', 'title': 'Complete your contact block',
                     'detail': 'Include a professional email, phone number and a LinkedIn/GitHub link at the top of the '
                               'resume. Missing contact data is a common reason parsers and recruiters drop otherwise good resumes.'})

    if by['summary']['status'] != 'present':
        recs.append({'priority': 'high' if by['summary']['status'] == 'missing' else 'medium',
                     'title': 'Strengthen your professional summary',
                     'detail': 'Write 2-4 sentences covering your years of experience, core stack and one measurable '
                               'headline achievement. This is the highest-leverage section for both recruiters and keyword matching.'})

    if c['metrics']['quantified'] < 3:
        q = c['metrics']['quantified']
        recs.append({'priority': 'high', 'title': 'Quantify your achievements',
                     'detail': f'Only {q} quantified result{"" if q == 1 else "s"} detected. Turn duties into outcomes, e.g. '
                               '"reduced API latency by 45%", "served 120k+ users", "cut deploy time from 2h to 15min". '
                               'Numbers make impact scannable.'})

    if c['metrics']['action_verbs'] < 5:
        recs.append({'priority': 'medium', 'title': 'Use stronger action verbs',
                     'detail': 'Start bullets with verbs like "designed", "led", "optimized", "automated", "shipped" '
                               'instead of passive phrasing like "responsible for".'})

    if mode == 'job_match':
        if c['skills_score'] is not None and c['skills_score'] < 60 and c['missing']:
            recs.append({'priority': 'high',
                         'title': f"Address skill gaps: {', '.join(c['missing'][:4])}",
                         'detail': 'Only add a skill if it genuinely reflects your experience. Where real, weave it into '
                                   'your summary, skills list and at least one experience bullet with evidence. If a skill '
                                   'is unfamiliar, consider a small project or course to build it first.'})
        if len(c['missing_keywords']) > 2:
            recs.append({'priority': 'medium', 'title': 'Mirror genuine JD keywords',
                         'detail': f"These job-description keywords are absent from your resume: "
                                   f"{', '.join(c['missing_keywords'][:6])}. Incorporate only the ones that truthfully "
                                   'describe your experience — never keyword-stuff terms you cannot back up in an interview.'})

    wc = c['metrics']['word_count']
    if wc < 300:
        recs.append({'priority': 'medium', 'title': 'Your resume is on the short side',
                     'detail': f'{wc} words detected. Resumes under ~300 words often underrepresent experience — '
                               'expand achievements, projects or a second role.'})
    elif wc > 1100:
        recs.append({'priority': 'low', 'title': 'Tighten the resume length',
                     'detail': f'{wc} words detected. Consider trimming older or less relevant content so the '
                               'strongest signals stay above the fold.'})

    if by['certifications']['status'] == 'missing':
        recs.append({'priority': 'low', 'title': 'Consider adding certifications',
                     'detail': 'Relevant certifications (e.g. cloud, data or framework-specific) add credibility — '
                               'but only list current, verifiable ones.'})

    if c['overall'] >= 75:
        recs.append({'priority': 'low', 'title': 'Strong profile — tailor per application',
                     'detail': 'Your resume already aligns well. For each application, re-run the analysis against that '
                               'specific job description and surface the most relevant projects first.'})

    # Ensure every user leaves with useful guidance, even when the resume is strong.
    if len(recs) < 3:
        recs.append({'priority': 'low', 'title': 'Mirror the JD in your headline and summary',
                     'detail': 'Move the 2-3 most relevant technologies and your exact target title into the top third '
                               'of the resume — recruiters scan that zone first, and parsers weight early content heavily.'})
    if len(recs) < 3:
        recs.append({'priority': 'low', 'title': 'Keep formatting parser-friendly',
                     'detail': 'Use a single-column layout, standard section headings and real bullet characters. '
                               'Text boxes, tables, icons and multi-column layouts frequently break automated parsers.'})

    order = {'high': 0, 'medium': 1, 'low': 2}
    return sorted(recs, key=lambda r: order[r['priority']])[:7]


def _summary(c: dict) -> str:
    pct = lambda n: f'{round(n)}%'
    if c['mode'] == 'job_match':
        o = c['overall']
        level = 'a strong' if o >= 75 else 'a moderate' if o >= 55 else 'a partial' if o >= 35 else 'a limited'
        parts = [f'Your resume shows {level} alignment with this role, scoring {o}/100 overall.']
        if c['jd_total'] > 0:
            gaps = f" — the biggest gaps are {', '.join(c['missing'][:3])}" if c['missing'] else ', with no critical skill gaps'
            parts.append(f"You match {len(c['matched'])} of {c['jd_total']} required skills "
                         f"({pct(c['skills_score'])}){gaps}.")
        parts.append(f"Textual similarity with the job description is {pct(c['sim_score'])} and keyword coverage "
                     f"is {pct(c['keyword_score'])}.")
        q = c['quality']
        parts.append(
            f"Document quality is solid ({q}/100) at {c['metrics']['word_count']} words with "
            f"{c['metrics']['quantified']} quantified results." if q >= 70 else
            f"The resume itself needs work ({q}/100): section completeness is {c['completeness']}% and only "
            f"{c['metrics']['quantified']} quantified achievements were found. Strengthening structure and "
            'measurable outcomes is your fastest win.')
        return ' '.join(parts)

    o = c['overall']
    level = 'a well-structured, credible' if o >= 75 else 'a decent but improvable' if o >= 55 else 'an under-developed'
    return ' '.join([
        f'This resume-only analysis (no job description provided) found {level} profile, scoring {o}/100 overall.',
        f"Quality scores {c['quality']}/100 with {c['completeness']}% section completeness, "
        f"{c['metrics']['word_count']} words, {c['metrics']['quantified']} quantified achievements and "
        f"{c['metrics']['bullets']} bullet points detected.",
        f"Your profile signals {c['resume_skill_count']} distinct technical and professional skills. Paste a job "
        'description to unlock skill-gap, keyword and TF-IDF similarity matching against a specific role.',
    ])


def analyze_resume_text(resume_text: str, jd_text: str = '', file_name: str = 'resume',
                        file_type: str = 'txt', demo: bool = False) -> dict:
    t0 = time.perf_counter()
    jd = (jd_text or '').strip()
    mode = 'job_match' if word_count(jd) >= 10 else 'quality'
    wc = word_count(resume_text)

    sections = detect_sections(resume_text)
    completeness = round(
        sum(1 if s['status'] == 'present' else 0.5 if s['status'] == 'attention' else 0 for s in sections)
        / len(sections) * 100
    )

    resume_skills = extract_skills(resume_text)
    jd_skills = extract_skills(jd) if mode == 'job_match' else []
    resume_names = {s['name'] for s in resume_skills}
    matched = [s['name'] for s in jd_skills if s['name'] in resume_names]
    missing = [s['name'] for s in jd_skills if s['name'] not in resume_names]

    quantified = len(QUANT_RE.findall(resume_text))
    bullets = sum(1 for line in resume_text.split('\n') if BULLET_RE.match(line))
    low = resume_text.lower()
    verbs_found = [v for v in ACTION_VERBS if re.search(rf'\b{v}\b', low)]
    date_ranges = len(DATE_RANGE_RE.findall(resume_text))
    metrics = {'word_count': wc, 'bullets': bullets, 'quantified': quantified,
               'action_verbs': len(verbs_found), 'verbs_found': verbs_found[:8], 'date_ranges': date_ranges}

    depth = _depth(sections, metrics)
    quality = _clamp(0.5 * completeness + 0.5 * depth)

    similarity_score = None
    jd_keywords: list[dict] = []
    keywords: list[str] = []
    missing_keywords: list[str] = []
    keyword_match_score = None

    if mode == 'job_match':
        similarity_score = _clamp(tfidf_cosine(resume_text, jd) * 100)
        jd_keywords = extract_jd_keywords(jd, resume_text)
        keywords = [k['term'] for k in jd_keywords if k['present']]
        missing_keywords = [k['term'] for k in jd_keywords if not k['present']]
        n = len(jd_keywords)
        total = covered = 0.0
        for i, k in enumerate(jd_keywords):
            w = (n - i) / n
            total += w
            covered += w if k['present'] else 0.0
        keyword_match_score = _clamp(covered / total * 100) if total else 0

    skills_match_score = None
    if mode == 'job_match':
        if jd_skills:
            skills_match_score = _clamp(len(matched) / len(jd_skills) * 100)
            weights = [{'label': 'Skill match', 'value': 30}, {'label': 'Keyword match', 'value': 25},
                       {'label': 'TF-IDF similarity', 'value': 20}, {'label': 'Resume quality', 'value': 25}]
            overall = _clamp(0.30 * skills_match_score + 0.25 * (keyword_match_score or 0)
                             + 0.20 * (similarity_score or 0) + 0.25 * quality)
        else:
            weights = [{'label': 'Keyword match', 'value': 40}, {'label': 'TF-IDF similarity', 'value': 25},
                       {'label': 'Resume quality', 'value': 35}]
            overall = _clamp(0.40 * (keyword_match_score or 0) + 0.25 * (similarity_score or 0) + 0.35 * quality)
    else:
        breadth = _clamp(len(resume_skills) / 15 * 100)
        richness = _clamp(len(set(tokenize(resume_text))) / 90 * 100)
        skills_match_score, keyword_match_score = breadth, richness
        weights = [{'label': 'Resume quality', 'value': 60}, {'label': 'Skill breadth', 'value': 25},
                   {'label': 'Keyword richness', 'value': 15}]
        overall = _clamp(0.60 * quality + 0.25 * breadth + 0.15 * richness)

    target = 100 if mode == 'job_match' else 85
    by = {s['key']: s for s in sections}
    exp_score = _clamp(_status_score(by['experience'], 70, 45, 10)
                       + min(date_ranges, 3) * 5 + (10 if quantified >= 3 else 5 if quantified >= 1 else 0))
    breadth_radar = _clamp(len(resume_skills) / 15 * 100)
    radar = [
        {'dimension': 'Technical Skills', 'resume': skills_match_score if skills_match_score is not None else breadth_radar, 'target': target},
        {'dimension': 'Keywords', 'resume': keyword_match_score or 0, 'target': target},
        {'dimension': 'Experience', 'resume': exp_score, 'target': target},
        {'dimension': 'Education', 'resume': _status_score(by['education']), 'target': target},
        {'dimension': 'Projects', 'resume': _status_score(by['projects']), 'target': target},
        {'dimension': 'Overall Alignment', 'resume': overall, 'target': target},
    ]
    cats: dict[str, int] = {}
    for s in resume_skills:
        cats[s['category']] = cats.get(s['category'], 0) + 1
    skill_distribution = sorted(({'category': k, 'count': v} for k, v in cats.items()),
                                key=lambda x: x['count'], reverse=True)

    ctx = {'mode': mode, 'overall': overall, 'quality': quality, 'skills_score': skills_match_score,
           'keyword_score': keyword_match_score or 0, 'sim_score': similarity_score or 0, 'matched': matched,
           'missing': missing, 'jd_total': len(jd_skills), 'missing_keywords': missing_keywords, 'sections': sections,
           'completeness': completeness, 'metrics': metrics, 'resume_skill_count': len(resume_skills)}

    return {
        'overall_score': overall,
        'resume_quality_score': quality,
        'keyword_match_score': keyword_match_score,
        'skills_match_score': skills_match_score,
        'similarity_score': similarity_score,
        'skills': [s['name'] for s in resume_skills],
        'jd_skills': [s['name'] for s in jd_skills],
        'matched_skills': matched,
        'missing_skills': missing,
        'skill_match_ratio': {'matched': len(matched), 'required': len(jd_skills)} if jd_skills else None,
        'keywords': keywords,
        'missing_keywords': missing_keywords,
        'jd_keywords': jd_keywords,
        'resume_top_keywords': top_resume_terms(resume_text),
        'sections': sections,
        'completeness_score': completeness,
        'metrics': {'word_count': wc, 'bullets': bullets, 'quantified_achievements': quantified,
                    'action_verb_count': len(verbs_found), 'action_verbs_found': verbs_found[:8],
                    'date_ranges': date_ranges},
        'recommendations': _recommendations(ctx),
        'summary': _summary(ctx),
        'charts': {'radar': radar, 'skill_distribution': skill_distribution},
        'weights': weights,
        'meta': {
            'file_name': file_name, 'file_type': file_type, 'word_count': wc, 'mode': mode, 'demo': demo,
            'processing_ms': max(1, round((time.perf_counter() - t0) * 1000)),
            'disclaimer': 'Scores estimate textual alignment and resume completeness using transparent NLP '
                          'heuristics. They do not guarantee ATS success, interviews, or hiring outcomes.',
        },
    }
