"""POST /api/analyze — multipart/form-data resume analysis endpoint.

Files are read into memory, analyzed and discarded. Nothing is persisted.
"""

import os

from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from app.models.schemas import AnalysisResponse
from app.nlp.text import normalize_raw, word_count
from app.parsers.extract import ALLOWED_EXTENSIONS, ParseError, extract_text, file_extension
from app.services.analyzer import analyze_resume_text

router = APIRouter(tags=['analysis'])

MAX_UPLOAD_BYTES = int(os.getenv('MAX_UPLOAD_MB', '5')) * 1024 * 1024


@router.post('/analyze', response_model=AnalysisResponse)
async def analyze(
    resume: UploadFile = File(..., description='Resume file: PDF, DOCX or TXT (<= 5 MB)'),
    job_description: str = Form('', description='Optional target job description'),
    demo: str = Form('false'),
) -> dict:
    filename = resume.filename or 'resume.txt'
    ext = file_extension(filename)
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(415, f'Unsupported file type ".{ext or "?"}". Please upload a PDF, DOCX or TXT resume.')

    data = await resume.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, 'File exceeds the 5 MB limit. Please upload a smaller resume.')
    if not data:
        raise HTTPException(400, 'The uploaded file is empty.')

    try:
        text = normalize_raw(extract_text(filename, data))
    except ParseError as exc:
        raise HTTPException(422, str(exc)) from exc

    if word_count(text) < 25:
        raise HTTPException(422, 'Not enough readable text was found in this file (minimum ~25 words). '
                                 'If this is a PDF, it may be a scanned image — try a text-based PDF, DOCX or TXT export.')

    result = analyze_resume_text(
        resume_text=text,
        jd_text=job_description[:50000],
        file_name=filename,
        file_type=ext,
        demo=str(demo).lower() == 'true',
    )
    return result
