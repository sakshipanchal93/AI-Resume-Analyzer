"""Resume text extraction: PDF (PyMuPDF), DOCX (python-docx), TXT.

Callers pass in-memory bytes only — files are never written to disk and never
persisted. Raises ValueError with a user-safe message on failure.
"""

import io

import fitz  # PyMuPDF
from docx import Document

ALLOWED_EXTENSIONS = {'pdf', 'docx', 'txt'}


class ParseError(ValueError):
    pass


def file_extension(filename: str) -> str:
    parts = str(filename or '').lower().rsplit('.', 1)
    return parts[-1] if len(parts) > 1 else ''


def extract_text(filename: str, data: bytes) -> str:
    ext = file_extension(filename)
    try:
        if ext == 'pdf':
            with fitz.open(stream=data, filetype='pdf') as doc:
                return '\n'.join(page.get_text() for page in doc)
        if ext == 'docx':
            document = Document(io.BytesIO(data))
            return '\n'.join(p.text for p in document.paragraphs)
        if ext == 'txt':
            return data.decode('utf-8', errors='replace')
        raise ParseError(f'Unsupported file type ".{ext or "?"}". Please upload a PDF, DOCX or TXT resume.')
    except ParseError:
        raise
    except Exception as exc:  # corrupt file, bad zip, fitz failure, ...
        if ext == 'pdf':
            raise ParseError(
                'Could not extract text from this PDF — it may be a scanned image or '
                'password-protected. Try a text-based PDF, DOCX or TXT export.'
            ) from exc
        raise ParseError(
            'Could not read this file. It may be corrupted — try re-exporting your resume '
            'as PDF, DOCX or TXT.'
        ) from exc
