import type { AnalysisResponse } from './types';

// Base URL for the API. Locally you can point this at the FastAPI backend
// (see .env.example); when unset it uses the same-origin /api serverless route.
const BASE = ((import.meta.env.VITE_API_URL as string | undefined) ?? '').replace(/\/$/, '');

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

export async function analyzeResume(
  file: File,
  jobDescription: string,
  demo = false,
  timeoutMs = 60000
): Promise<AnalysisResponse> {
  const fd = new FormData();
  fd.append('resume', file);
  fd.append('job_description', jobDescription);
  if (demo) fd.append('demo', 'true');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(`${BASE}/api/analyze`, { method: 'POST', body: fd, signal: controller.signal });
    const text = await res.text();
    let data: unknown = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      /* non-JSON error body */
    }
    if (!res.ok) {
      const msg = (data as { error?: string }).error || `Analysis failed (HTTP ${res.status}). Please try again.`;
      throw new ApiError(msg, res.status);
    }
    return data as AnalysisResponse;
  } catch (err) {
    if (err instanceof ApiError) throw err;
    if ((err as DOMException)?.name === 'AbortError') {
      throw new ApiError('The analysis timed out after 60s. Try a smaller file or a shorter job description.', 408);
    }
    throw new ApiError('Could not reach the analysis service. Check your connection and try again.', 0);
  } finally {
    clearTimeout(timer);
  }
}

export function validateResumeFile(file: File): string | null {
  const ext = file.name.toLowerCase().split('.').pop() || '';
  if (!['pdf', 'docx', 'txt'].includes(ext)) {
    return `Unsupported file type ".${ext}". Please upload a PDF, DOCX or TXT resume.`;
  }
  if (file.size === 0) return 'This file is empty. Please upload a valid resume.';
  if (file.size > 5 * 1024 * 1024) return 'File exceeds the 5 MB limit. Please upload a smaller file.';
  return null;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
