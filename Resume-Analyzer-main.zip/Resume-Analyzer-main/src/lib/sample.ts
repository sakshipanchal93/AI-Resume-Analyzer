// Demo fixtures — a realistic sample resume + JD used ONLY when the user
// explicitly clicks "Try Demo". Demo runs go through the same real API and are
// clearly labeled in the UI; they are never mixed with user analyses.

export const SAMPLE_RESUME = `Aarav Sharma
Bengaluru, India
aarav.sharma@email.com | +91 98765 43210 | linkedin.com/in/aaravsharma | github.com/aaravsharma

PROFESSIONAL SUMMARY
Full-stack software engineer with 5+ years of experience building scalable web applications and data-driven services. Strong background in React, TypeScript, Node.js and Python, with hands-on experience deploying cloud-native systems on AWS. Passionate about clean architecture, developer experience and measurable business impact.

TECHNICAL SKILLS
Languages: Python, JavaScript, TypeScript, SQL
Frontend: React, Redux, HTML, CSS, Tailwind CSS
Backend: Node.js, Express, FastAPI, REST API, Microservices
Databases: PostgreSQL, MongoDB, Redis
Cloud & DevOps: AWS, Docker, CI/CD, GitHub Actions, Linux, Git, GitHub
Data: Pandas, NumPy, Scikit-Learn, Machine Learning

PROFESSIONAL EXPERIENCE
Senior Software Engineer, FinEdge Technologies, Bengaluru
2021 - Present
- Designed and shipped a React and TypeScript analytics dashboard used by 40,000+ monthly active users, improving report load time by 62%.
- Built FastAPI microservices on AWS with PostgreSQL, processing 2M+ transactions daily at 99.95% uptime.
- Led migration to a microservices architecture, reducing deployment time from 2 hours to 15 minutes using Docker and CI/CD pipelines.
- Mentored 4 junior engineers and introduced automated testing practices that raised coverage from 38% to 85%.

Software Engineer, CloudKart Solutions
2019 - 2021
- Developed Node.js and Express REST APIs powering a marketplace with 120,000+ users.
- Optimized PostgreSQL queries and Redis caching, cutting p95 API latency by 45%.
- Implemented a real-time notification service using WebSockets and MongoDB for 30,000 daily orders.

PROJECTS
ResumeMatch, NLP-based resume screening tool (Python, Scikit-Learn, FastAPI, React). TF-IDF similarity ranking with skill extraction, reaching 88% precision on labeled evaluation data.
DevBoard, developer productivity dashboard (Next.js, PostgreSQL, Docker) adopted by 30+ internal teams.

EDUCATION
B.E. in Computer Science, Visvesvaraya Technological University
2015 - 2019, CGPA 8.7/10

CERTIFICATIONS
AWS Certified Solutions Architect - Associate (2023)
MongoDB Certified Developer (2022)

ACHIEVEMENTS
Won the company hackathon 2022 (1st place among 42 teams) for an ML-based fraud-detection prototype.
Speaker at BengaluruJS meetup on React performance optimization (150+ attendees).
`;

export const SAMPLE_JD = `Senior Software Engineer, Payments Platform

We are looking for a Senior Software Engineer to join our payments team. You will design, build and operate large-scale distributed services that move money reliably for millions of customers every day.

Responsibilities:
- Design and develop microservices and REST API / GraphQL endpoints in TypeScript and Node.js.
- Build rich, accessible frontends with React, TypeScript and Tailwind CSS.
- Model data and tune queries in PostgreSQL; use Redis for caching hot paths.
- Deploy and operate containerized workloads with Docker and Kubernetes on AWS.
- Own quality through unit testing with Jest, integration testing and CI/CD automation.
- Collaborate in an Agile environment; lead code reviews, system design discussions and incident response.

Requirements:
- 4+ years of professional software engineering experience.
- Strong TypeScript, React and Node.js skills; experience with GraphQL is a strong plus.
- Solid SQL and PostgreSQL knowledge; familiarity with Redis and message queues such as Kafka.
- Hands-on production experience with AWS, Docker and Kubernetes.
- Experience writing unit tests with Jest and running CI/CD pipelines.
- Understanding of microservices, distributed systems, observability and monitoring.
- Excellent communication skills and a pragmatic, product-minded approach.

Nice to have: payment systems experience, Terraform, and event-driven architecture with Kafka.
`;
