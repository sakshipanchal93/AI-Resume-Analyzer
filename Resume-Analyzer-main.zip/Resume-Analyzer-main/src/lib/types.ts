export type SectionStatus = 'present' | 'attention' | 'missing';

export interface SectionInfo {
  key: string;
  label: string;
  status: SectionStatus;
  words: number;
  detail: string;
}

export interface Recommendation {
  title: string;
  detail: string;
  priority: 'high' | 'medium' | 'low';
}

export interface RadarPoint {
  dimension: string;
  resume: number;
  target: number;
}

export interface SkillCategoryCount {
  category: string;
  count: number;
}

export interface JdKeyword {
  term: string;
  count: number;
  present: boolean;
}

export interface WeightInfo {
  label: string;
  value: number;
}

export interface AnalysisMeta {
  file_name: string;
  file_type: string;
  word_count: number;
  mode: 'job_match' | 'quality';
  demo: boolean;
  processing_ms: number;
  disclaimer: string;
}

export interface AnalysisResponse {
  overall_score: number;
  resume_quality_score: number;
  keyword_match_score: number | null;
  skills_match_score: number | null;
  similarity_score: number | null;
  skills: string[];
  jd_skills: string[];
  matched_skills: string[];
  missing_skills: string[];
  skill_match_ratio: { matched: number; required: number } | null;
  keywords: string[];
  missing_keywords: string[];
  jd_keywords: JdKeyword[];
  resume_top_keywords: string[];
  sections: SectionInfo[];
  completeness_score: number;
  metrics: {
    word_count: number;
    bullets: number;
    quantified_achievements: number;
    action_verb_count: number;
    action_verbs_found: string[];
    date_ranges: number;
  };
  recommendations: Recommendation[];
  summary: string;
  charts: { radar: RadarPoint[]; skill_distribution: SkillCategoryCount[] };
  weights: WeightInfo[];
  meta: AnalysisMeta;
}
