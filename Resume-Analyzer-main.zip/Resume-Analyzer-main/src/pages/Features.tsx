import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  BarChart3,
  BadgeCheck,
  FileText,
  Gauge,
  ListChecks,
  Lock,
  Puzzle,
  Sparkles,
  Target,
  Zap,
} from 'lucide-react';
import { GlassCard, PageHeader } from '../components/ui';

const FEATURES = [
  {
    icon: FileText,
    title: 'Multi-Format Resume Parsing',
    points: [
      'PDF via pdf-parse (PyMuPDF in the FastAPI backend)',
      'DOCX via mammoth (python-docx in the backend)',
      'Plain TXT with encoding normalization',
      'Automatic rejection of empty, corrupt or scanned files with helpful errors',
    ],
  },
  {
    icon: Sparkles,
    title: 'Skill Extraction Engine',
    points: [
      '60+ skills across languages, frontend, backend, data/ML, cloud and practices',
      'Alias-aware: C++, C#, Node.js, Scikit-Learn, CI/CD all resolve correctly',
      'Canonicalization pipeline normalizes punctuation and casing before matching',
      'Dictionary is a single declarative list — trivially extensible',
    ],
  },
  {
    icon: Target,
    title: 'Job Match Scoring',
    points: [
      'TF-IDF vectorization (sublinear TF, smoothed IDF) of resume vs. JD',
      'Cosine similarity over the shared vocabulary',
      'Rank-weighted keyword coverage of top JD terms',
      'Weighted overall score with documented, visible formula',
    ],
  },
  {
    icon: Puzzle,
    title: 'Gap Analysis',
    points: [
      'Missing required skills surfaced as amber badges with an honesty reminder',
      'Missing JD keywords with rank-weighted importance',
      'Skill match ratio (e.g. 11/16) with animated progress',
      'Gap lists double as a personalized learning roadmap',
    ],
  },
  {
    icon: Gauge,
    title: 'Resume Quality Audit',
    points: [
      'Completeness across 8 sections: Contact → Achievements',
      'Status per section: Present / Needs Attention / Missing',
      'Depth metrics: bullets, quantified results, action verbs, word count',
      'Quality score = 50% structure + 50% depth',
    ],
  },
  {
    icon: Zap,
    title: 'Instant, Written Feedback',
    points: [
      'Recommendations generated dynamically from detected weaknesses',
      'Prioritized high / medium / low with concrete examples',
      'Auto-written summary you can copy with one click',
      'Runs entirely server-side in well under a second',
    ],
  },
];

const EXTRAS = [
  {
    icon: BarChart3,
    title: 'Data Visualization',
    desc: 'A radar chart compares your resume against job requirements across six dimensions, and a bar chart maps your skill distribution by category — both theme-aware and fully responsive.',
  },
  {
    icon: ListChecks,
    title: 'Resume-Only Mode',
    desc: 'No job description? The analyzer pivots to a quality-focused audit: completeness, depth, skill breadth and keyword richness — with the weights rebalanced transparently.',
  },
  {
    icon: Lock,
    title: 'Privacy by Architecture',
    desc: "Resumes are streamed to memory, analyzed, and discarded. There is no database write, no disk persistence, and no analytics on your document's contents.",
  },
];

export default function Features() {
  return (
    <div className="mx-auto max-w-7xl px-4 pt-16 pb-8 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Feature Deep-Dive"
        title={
          <>
            Real NLP, <span className="text-gradient">real answers</span>
          </>
        }
        subtitle="Every feature below runs on the live analysis pipeline — parsing, extraction, vectorization and scoring all happen server-side on your actual document."
      />

      <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
          >
            <GlassCard className="h-full p-6">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600/15 to-cyan-500/15 text-violet-600 dark:text-violet-300">
                <f.icon size={20} />
              </span>
              <h3 className="font-display mt-4 text-base font-bold text-slate-900 dark:text-white">{f.title}</h3>
              <ul className="mt-3 space-y-2">
                {f.points.map((p) => (
                  <li key={p} className="flex items-start gap-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">
                    <BadgeCheck size={14} className="mt-0.5 shrink-0 text-emerald-500" />
                    {p}
                  </li>
                ))}
              </ul>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-3">
        {EXTRAS.map((x) => (
          <GlassCard key={x.title} className="p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600/15 to-cyan-500/15 text-indigo-500 dark:text-indigo-300">
              <x.icon size={20} />
            </span>
            <h3 className="font-display mt-4 text-base font-bold text-slate-900 dark:text-white">{x.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{x.desc}</p>
          </GlassCard>
        ))}
      </div>

      <div className="mt-14 text-center">
        <Link
          to="/analyzer"
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-500 px-8 py-3.5 text-sm font-bold text-white shadow-xl shadow-violet-600/25 transition-all hover:brightness-110"
        >
          See it on your resume <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}
