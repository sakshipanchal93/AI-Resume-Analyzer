import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  BadgeCheck,
  FileSearch,
  FileText,
  FlaskConical,
  Gauge,
  Puzzle,
  ScanText,
  ShieldCheck,
  Sparkles,
  Target,
  Zap,
} from 'lucide-react';
import { GlassCard } from '../components/ui';

const FEATURES = [
  {
    icon: FileText,
    title: 'Resume Parsing',
    desc: 'PDF, DOCX and TXT extraction with structure detection — sections, bullets and contact info are identified automatically.',
  },
  {
    icon: Sparkles,
    title: 'AI Skill Extraction',
    desc: 'A 60+ entry skill dictionary with alias resolution surfaces your true technical profile — from Python to Kubernetes.',
  },
  {
    icon: Target,
    title: 'Job Match Score',
    desc: 'TF-IDF vectorization and cosine similarity quantify how closely your resume aligns with a target job description.',
  },
  {
    icon: Puzzle,
    title: 'Missing Skills & Keywords',
    desc: 'See exactly which required skills and high-signal JD keywords are absent — with honest guidance on closing gaps.',
  },
  {
    icon: Gauge,
    title: 'Resume Quality Audit',
    desc: 'An 8-section completeness check plus content-depth metrics: quantified achievements, action verbs, length and more.',
  },
  {
    icon: Zap,
    title: 'Instant Feedback',
    desc: 'Dynamic recommendations and a written summary generated from your actual results — copy, act, re-analyze.',
  },
];

const TECH = [
  { name: 'Python', dot: 'bg-blue-400' },
  { name: 'NLP', dot: 'bg-violet-400' },
  { name: 'Scikit-Learn', dot: 'bg-orange-400' },
  { name: 'FastAPI', dot: 'bg-emerald-400' },
  { name: 'React', dot: 'bg-cyan-400' },
  { name: 'Tailwind', dot: 'bg-sky-300' },
  { name: 'Recharts', dot: 'bg-rose-400' },
];

const WEIGHTS = [
  { label: 'Skill match', value: 30, color: 'from-violet-500 to-violet-400' },
  { label: 'Keyword match', value: 25, color: 'from-indigo-500 to-indigo-400' },
  { label: 'TF-IDF similarity', value: 20, color: 'from-cyan-500 to-cyan-400' },
  { label: 'Resume quality', value: 25, color: 'from-emerald-500 to-emerald-400' },
];

const rise = {
  hidden: { opacity: 0, y: 26 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] as const } },
};

export default function Home() {
  return (
    <div>
      {/* ------------------------------------------------------------- HERO */}
      <section className="relative mx-auto max-w-7xl px-4 pt-20 pb-16 sm:px-6 lg:px-8 lg:pt-28">
        <div className="mx-auto max-w-4xl text-center">
          <motion.div variants={rise} initial="hidden" animate="show">
            <span className="inline-flex items-center gap-2 rounded-full border border-violet-500/25 bg-violet-500/10 px-4 py-1.5 text-xs font-semibold text-violet-700 dark:text-violet-300">
              <Sparkles size={13} />
              NLP · TF-IDF Vectorization · Cosine Similarity
            </span>
          </motion.div>

          <motion.h1
            variants={rise}
            initial="hidden"
            animate="show"
            transition={{ delay: 0.08 }}
            className="font-display mt-7 text-4xl leading-[1.12] font-extrabold tracking-tight text-slate-900 sm:text-5xl lg:text-[3.6rem] dark:text-white"
          >
            Analyze your resume.
            <br />
            <span className="text-gradient">Match it with the right job.</span>
            <br />
            Discover exactly what you're missing.
          </motion.h1>

          <motion.p
            variants={rise}
            initial="hidden"
            animate="show"
            transition={{ delay: 0.16 }}
            className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-slate-500 sm:text-lg dark:text-slate-400"
          >
            AlignAI parses your resume, extracts your real skill profile and compares it against any job description with
            transparent, explainable machine-learning scoring — no black boxes, no signup, no storage of your data.
          </motion.p>

          <motion.div
            variants={rise}
            initial="hidden"
            animate="show"
            transition={{ delay: 0.24 }}
            className="mt-9 flex flex-col items-center justify-center gap-3.5 sm:flex-row"
          >
            <Link
              to="/analyzer"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-500 px-8 py-3.5 text-sm font-bold text-white shadow-xl shadow-violet-600/30 transition-all hover:shadow-violet-600/50 hover:brightness-110 sm:w-auto"
            >
              Analyze My Resume <ArrowRight size={16} />
            </Link>
            <Link
              to="/analyzer?demo=1"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white/70 px-8 py-3.5 text-sm font-bold text-slate-700 backdrop-blur transition-colors hover:border-violet-400 hover:text-violet-600 sm:w-auto dark:border-white/15 dark:bg-white/5 dark:text-slate-200 dark:hover:border-violet-400/50 dark:hover:text-violet-300"
            >
              <FlaskConical size={16} /> Try Demo
            </Link>
          </motion.div>

          <motion.p
            variants={rise}
            initial="hidden"
            animate="show"
            transition={{ delay: 0.32 }}
            className="mt-5 flex items-center justify-center gap-1.5 text-xs text-slate-400 dark:text-slate-500"
          >
            <ShieldCheck size={13} className="text-emerald-500" />
            Free to use · No account · Resumes are analyzed in memory and never stored
          </motion.p>

          {/* tech badges */}
          <motion.div
            variants={rise}
            initial="hidden"
            animate="show"
            transition={{ delay: 0.4 }}
            className="mt-10 flex flex-wrap items-center justify-center gap-2"
          >
            {TECH.map((t) => (
              <span
                key={t.name}
                className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/60 px-3 py-1.5 text-xs font-semibold text-slate-600 backdrop-blur dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
              >
                <span className={`h-1.5 w-1.5 rounded-full ${t.dot}`} />
                {t.name}
              </span>
            ))}
          </motion.div>
        </div>

        {/* floating preview card */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto mt-16 max-w-3xl"
        >
          <div className="animate-floaty">
            <GlassCard className="overflow-hidden rounded-3xl p-0 shadow-2xl shadow-violet-500/10">
              <div className="flex items-center gap-2 border-b border-slate-200/70 px-5 py-3 dark:border-white/[0.07]">
                <span className="h-2.5 w-2.5 rounded-full bg-rose-400/80" />
                <span className="h-2.5 w-2.5 rounded-full bg-amber-400/80" />
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/80" />
                <span className="ml-3 inline-flex items-center gap-1.5 text-xs font-medium text-slate-400">
                  <ScanText size={12} /> alignai · analysis dashboard
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 p-5 sm:grid-cols-4">
                {[
                  { label: 'Overall Match', v: '78', cls: 'text-emerald-500' },
                  { label: 'Resume Quality', v: '84', cls: 'text-emerald-500' },
                  { label: 'Skills Match', v: '71', cls: 'text-amber-500' },
                  { label: 'Keyword Match', v: '69', cls: 'text-amber-500' },
                ].map((s) => (
                  <div key={s.label} className="rounded-2xl border border-slate-200/70 bg-white/60 p-4 text-center dark:border-white/[0.07] dark:bg-white/[0.03]">
                    <p className={`font-display text-2xl font-bold tabular-nums ${s.cls}`}>{s.v}</p>
                    <p className="mt-1 text-[10px] font-bold tracking-wider text-slate-400 uppercase">{s.label}</p>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-1.5 px-5 pb-5">
                {['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'AWS', 'Docker'].map((s) => (
                  <span key={s} className="rounded-lg border border-emerald-500/25 bg-emerald-500/10 px-2 py-0.5 text-[11px] font-semibold text-emerald-600 dark:text-emerald-300">{s}</span>
                ))}
                {['Kubernetes', 'GraphQL'].map((s) => (
                  <span key={s} className="rounded-lg border border-amber-500/25 bg-amber-500/10 px-2 py-0.5 text-[11px] font-semibold text-amber-600 dark:text-amber-300">+ {s}</span>
                ))}
              </div>
            </GlassCard>
          </div>
        </motion.div>
      </section>

      {/* ---------------------------------------------------------- FEATURES */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-bold tracking-[0.18em] text-violet-600 uppercase dark:text-violet-400">Capabilities</span>
          <h2 className="font-display mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
            Everything you need to <span className="text-gradient">close the gap</span>
          </h2>
          <p className="mt-4 text-slate-500 dark:text-slate-400">
            Six analysis engines working together on every upload — each one explainable, each one instant.
          </p>
        </div>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              variants={rise}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true, margin: '-80px' }}
              transition={{ delay: (i % 3) * 0.08 }}
            >
              <GlassCard className="group h-full p-6 transition-all duration-300 hover:-translate-y-1 hover:border-violet-400/40 hover:shadow-xl hover:shadow-violet-500/[0.08]">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600/15 to-cyan-500/15 text-violet-600 transition-transform group-hover:scale-110 dark:text-violet-300">
                  <f.icon size={20} />
                </span>
                <h3 className="font-display mt-4 text-base font-bold text-slate-900 dark:text-white">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{f.desc}</p>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ------------------------------------------------- SCORING TRANSPARENCY */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="glass grid items-center gap-10 rounded-3xl p-8 sm:p-12 lg:grid-cols-2">
          <div>
            <span className="text-xs font-bold tracking-[0.18em] text-violet-600 uppercase dark:text-violet-400">Transparent scoring</span>
            <h2 className="font-display mt-3 text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              A score you can <span className="text-gradient">actually audit</span>
            </h2>
            <p className="mt-4 leading-relaxed text-slate-500 dark:text-slate-400">
              Every overall score is a documented weighted blend of four independently computed signals. Hover any gauge in
              the dashboard to see exactly how it was produced — and what would move it.
            </p>
            <p className="mt-3 text-xs leading-relaxed text-slate-400 dark:text-slate-500">
              Honest by design: no score here — or anywhere — can guarantee ATS or hiring outcomes. We optimize for clarity,
              not false certainty.
            </p>
            <Link
              to="/how-it-works"
              className="mt-6 inline-flex items-center gap-1.5 text-sm font-bold text-violet-600 hover:gap-2.5 dark:text-violet-300"
            >
              Read the methodology <ArrowRight size={15} />
            </Link>
          </div>
          <div className="space-y-4">
            {WEIGHTS.map((w) => (
              <div key={w.label}>
                <div className="mb-1.5 flex items-center justify-between text-sm">
                  <span className="font-semibold text-slate-700 dark:text-slate-200">{w.label}</span>
                  <span className="font-display font-bold text-slate-900 tabular-nums dark:text-white">{w.value}%</span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${w.value}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, ease: 'easeOut' }}
                    className={`h-full rounded-full bg-gradient-to-r ${w.color}`}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ----------------------------------------------------------------- CTA */}
      <section className="mx-auto max-w-7xl px-4 py-16 pb-8 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-violet-600 via-indigo-600 to-cyan-500 p-10 text-center shadow-2xl shadow-violet-600/25 sm:p-14">
          <div className="pointer-events-none absolute inset-0 opacity-20 [background-image:radial-gradient(circle_at_30%_20%,white,transparent_40%)]" />
          <FileSearch className="mx-auto h-10 w-10 text-white/90" />
          <h2 className="font-display mx-auto mt-4 max-w-xl text-3xl font-bold tracking-tight text-white">
            Find out what your resume is missing — in under a minute
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-sm leading-relaxed text-white/85">
            Upload once, get scores, gaps and a prioritized action list. Iterate until the gauge turns green.
          </p>
          <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              to="/analyzer"
              className="inline-flex items-center gap-2 rounded-xl bg-white px-7 py-3 text-sm font-bold text-violet-700 shadow-lg transition-transform hover:scale-[1.03]"
            >
              Analyze My Resume <ArrowRight size={15} />
            </Link>
            <Link
              to="/analyzer?demo=1"
              className="inline-flex items-center gap-2 rounded-xl border border-white/40 px-7 py-3 text-sm font-bold text-white transition-colors hover:bg-white/10"
            >
              <BadgeCheck size={15} /> Try Demo
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
