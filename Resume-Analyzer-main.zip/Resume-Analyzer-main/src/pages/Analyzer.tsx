import { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AlertTriangle, FlaskConical, RotateCcw, ScanSearch, ShieldCheck, Sparkles } from 'lucide-react';
import { analyzeResume, validateResumeFile } from '../lib/api';
import type { AnalysisResponse } from '../lib/types';
import { SAMPLE_JD, SAMPLE_RESUME } from '../lib/sample';
import { GlassCard, PageHeader } from '../components/ui';
import Dropzone from '../components/Dropzone';
import JdPanel from '../components/JdPanel';
import AnalysisSkeleton from '../components/results/Skeletons';
import ResultsDashboard from '../components/ResultsDashboard';

type Status = 'idle' | 'loading' | 'success' | 'error';

export default function Analyzer() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [jd, setJd] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [result, setResult] = useState<AnalysisResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [demo, setDemo] = useState(false);
  const resultsRef = useRef<HTMLDivElement>(null);
  const demoRan = useRef(false);

  const runAnalysis = useCallback(async (f: File, jdText: string, isDemo: boolean) => {
    setStatus('loading');
    setError(null);
    setResult(null);
    try {
      const data = await analyzeResume(f, jdText, isDemo);
      setResult(data);
      setStatus('success');
      setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 150);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
      setStatus('error');
      setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 150);
    }
  }, []);

  const runDemo = useCallback(() => {
    const demoFile = new File([SAMPLE_RESUME], 'demo-resume-aarav-sharma.txt', { type: 'text/plain' });
    setFile(demoFile);
    setFileError(null);
    setJd(SAMPLE_JD);
    setDemo(true);
    void runAnalysis(demoFile, SAMPLE_JD, true);
  }, [runAnalysis]);

  // "Try Demo" deep-link from the hero: /analyzer?demo=1
  useEffect(() => {
    if (searchParams.get('demo') === '1' && !demoRan.current) {
      demoRan.current = true;
      setSearchParams({}, { replace: true });
      runDemo();
    }
  }, [searchParams, setSearchParams, runDemo]);

  const handleAnalyzeClick = () => {
    if (!file) {
      setFileError('Please upload your resume first (PDF, DOCX or TXT).');
      return;
    }
    const err = validateResumeFile(file);
    if (err) {
      setFileError(err);
      return;
    }
    // A user-triggered run is never demo, even if the demo file is selected.
    setDemo(false);
    void runAnalysis(file, jd, false);
  };

  const reset = () => {
    setFile(null);
    setFileError(null);
    setJd('');
    setStatus('idle');
    setResult(null);
    setError(null);
    setDemo(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const loading = status === 'loading';

  return (
    <div className="mx-auto max-w-7xl px-4 pt-14 pb-8 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="NLP-Powered Analysis"
        title={
          <>
            Analyze your <span className="text-gradient">resume</span>
          </>
        }
        subtitle="Upload your resume and optionally paste a job description. AlignAI parses the document, extracts skills and keywords, and computes a transparent, weighted match — in seconds."
      />

      {/* ------------------------------ input form ------------------------------ */}
      <div className="mx-auto mt-10 max-w-5xl">
        <div className="grid gap-5 lg:grid-cols-2">
          <GlassCard className="p-6">
            <h3 className="mb-3 text-sm font-semibold text-slate-800 dark:text-slate-100">
              Your Resume <span className="ml-1 text-xs font-medium text-rose-500">*required</span>
            </h3>
            <Dropzone
              file={file}
              error={fileError}
              disabled={loading}
              onError={setFileError}
              onSelect={(f) => {
                setFile(f);
                setDemo(false);
              }}
              onRemove={() => setFile(null)}
            />
          </GlassCard>

          <GlassCard className="p-6">
            <JdPanel value={jd} disabled={loading} onChange={setJd} />
          </GlassCard>
        </div>

        <div className="mt-6 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
          <button
            onClick={handleAnalyzeClick}
            disabled={loading || !file}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-500 px-8 py-3.5 text-sm font-bold text-white shadow-xl shadow-violet-600/25 transition-all enabled:hover:shadow-violet-600/45 enabled:hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-45 sm:w-auto"
          >
            {loading ? (
              <>
                <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                </svg>
                Analyzing…
              </>
            ) : (
              <>
                <ScanSearch size={17} /> Analyze Resume
              </>
            )}
          </button>
          <button
            onClick={runDemo}
            disabled={loading}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-violet-500/30 bg-violet-500/10 px-6 py-3.5 text-sm font-bold text-violet-700 transition-colors hover:bg-violet-500/20 disabled:opacity-45 sm:w-auto dark:text-violet-300"
          >
            <FlaskConical size={16} /> Try Demo
          </button>
          <button
            onClick={reset}
            disabled={loading}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 px-6 py-3.5 text-sm font-semibold text-slate-500 transition-colors hover:border-slate-300 hover:text-slate-700 disabled:opacity-45 sm:w-auto dark:border-white/10 dark:text-slate-400 dark:hover:text-slate-200"
          >
            <RotateCcw size={15} /> Reset
          </button>
        </div>

        <div className="mt-5 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-slate-400 dark:text-slate-500">
          <span className="inline-flex items-center gap-1.5">
            <ShieldCheck size={13} className="text-emerald-500" /> Files are processed in memory — never stored
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Sparkles size={13} className="text-violet-500" /> TF-IDF + cosine similarity on every run
          </span>
        </div>
      </div>

      {/* ------------------------------ results zone ------------------------------ */}
      <div ref={resultsRef} className="scroll-mt-24">
        {loading && <AnalysisSkeleton />}

        {status === 'error' && (
          <div className="mx-auto mt-10 max-w-2xl rounded-2xl border border-rose-500/30 bg-rose-500/[0.06] p-6 text-center dark:bg-rose-500/[0.08]">
            <span className="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-rose-500/15 text-rose-500">
              <AlertTriangle size={20} />
            </span>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Analysis failed</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">{error}</p>
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              <button
                onClick={handleAnalyzeClick}
                className="rounded-xl bg-gradient-to-r from-violet-600 to-indigo-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-violet-600/20"
              >
                Try Again
              </button>
              <button
                onClick={reset}
                className="rounded-xl border border-slate-200 px-5 py-2.5 text-sm font-semibold text-slate-600 dark:border-white/10 dark:text-slate-300"
              >
                Start Over
              </button>
            </div>
          </div>
        )}

        {status === 'success' && result && (
          <>
            {result.meta.demo && (
              <div className="mx-auto mt-10 flex max-w-3xl items-center justify-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/[0.08] px-4 py-2.5 text-center text-xs font-semibold text-amber-700 dark:text-amber-300">
                <FlaskConical size={14} className="shrink-0" />
                Demo mode — you are viewing a sample resume analyzed against a sample Software Engineer JD. Upload your own
                resume for real results.
              </div>
            )}
            <ResultsDashboard data={result} onReset={reset} />
          </>
        )}
      </div>
    </div>
  );
}
