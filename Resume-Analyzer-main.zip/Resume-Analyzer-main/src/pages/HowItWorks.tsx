import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  Braces,
  CircleAlert,
  Cog,
  FileUp,
  FunctionSquare,
  ScanSearch,
  Sigma,
} from 'lucide-react';
import { GlassCard, PageHeader } from '../components/ui';

const STEPS = [
  {
    icon: FileUp,
    step: '01',
    title: 'Upload & Parse',
    desc: 'Your resume (PDF, DOCX or TXT) is posted as multipart/form-data to POST /api/analyze. The parser extracts raw text entirely in memory — the file is never written to a database or disk.',
  },
  {
    icon: Cog,
    step: '02',
    title: 'Normalize & Structure',
    desc: 'Text is cleaned, canonicalized (C++→cplusplus, Node.js→nodejs, Scikit-Learn→scikitlearn) and scanned for the 8 standard sections. Bullets, quantified achievements and action verbs are counted.',
  },
  {
    icon: ScanSearch,
    step: '03',
    title: 'NLP Extraction & Matching',
    desc: 'A 60+ skill dictionary extracts skills from both documents. Relevant terms are ranked by frequency × specificity, and both texts are projected into a shared TF-IDF vector space for cosine similarity.',
  },
  {
    icon: Sigma,
    step: '04',
    title: 'Score & Explain',
    desc: 'Skill match, keyword coverage, similarity and quality are blended into a weighted overall score. Recommendations and a written summary are generated dynamically from the detected gaps.',
  },
];

const FORMULA = [
  { term: 'skills_match', weight: 0.3, meaning: 'JD skills found in resume ÷ JD skills required' },
  { term: 'keyword_match', weight: 0.25, meaning: 'Rank-weighted coverage of top-12 JD keywords' },
  { term: 'similarity', weight: 0.2, meaning: 'cos(TF-IDF(resume), TF-IDF(jd)) · sublinear TF, smoothed IDF' },
  { term: 'quality', weight: 0.25, meaning: '50% section completeness + 50% content depth' },
];

export default function HowItWorks() {
  return (
    <div className="mx-auto max-w-7xl px-4 pt-16 pb-8 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Under the Hood"
        title={
          <>
            How the <span className="text-gradient">analysis works</span>
          </>
        }
        subtitle="Four stages, all deterministic and explainable. No opaque deep-learning verdicts — every number on the dashboard traces back to math you can inspect."
      />

      {/* steps */}
      <div className="relative mx-auto mt-14 max-w-4xl">
        <div className="absolute top-0 bottom-0 left-[27px] hidden w-px bg-gradient-to-b from-violet-500/50 via-indigo-500/30 to-transparent sm:block" />
        <ol className="space-y-6">
          {STEPS.map((s, i) => (
            <motion.li
              key={s.step}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
              className="flex gap-5"
            >
              <div className="relative z-10 flex flex-col items-center">
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-500 text-white shadow-lg shadow-violet-600/25">
                  <s.icon size={22} />
                </span>
              </div>
              <GlassCard className="flex-1 p-6">
                <div className="flex items-center gap-3">
                  <span className="font-display text-xs font-bold tracking-widest text-violet-600 dark:text-violet-300">{s.step}</span>
                  <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">{s.title}</h3>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{s.desc}</p>
              </GlassCard>
            </motion.li>
          ))}
        </ol>
      </div>

      {/* formula */}
      <div className="mx-auto mt-16 max-w-4xl">
        <GlassCard className="p-8">
          <div className="flex items-center gap-2.5">
            <FunctionSquare size={20} className="text-violet-500" />
            <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white">The overall score</h3>
          </div>
          <div className="mt-4 overflow-x-auto rounded-xl bg-slate-900 px-5 py-4 dark:bg-black/40">
            <code className="font-mono text-[13px] leading-relaxed text-cyan-300">
              overall = <span className="text-violet-300">0.30</span>·skills_match + <span className="text-violet-300">0.25</span>·keyword_match +{' '}
              <span className="text-violet-300">0.20</span>·tfidf_similarity + <span className="text-violet-300">0.25</span>·quality
            </code>
          </div>
          <ul className="mt-5 grid gap-3 sm:grid-cols-2">
            {FORMULA.map((f) => (
              <li key={f.term} className="rounded-xl border border-slate-200/70 bg-white/50 p-4 dark:border-white/[0.07] dark:bg-white/[0.02]">
                <div className="flex items-center justify-between">
                  <code className="font-mono text-xs font-bold text-violet-600 dark:text-violet-300">{f.term}</code>
                  <span className="font-display text-sm font-bold text-slate-900 dark:text-white">{Math.round(f.weight * 100)}%</span>
                </div>
                <p className="mt-1.5 text-xs leading-relaxed text-slate-500 dark:text-slate-400">{f.meaning}</p>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs leading-relaxed text-slate-400 dark:text-slate-500">
            When the JD contains no dictionary skills, weights rebalance to keywords 40 / similarity 25 / quality 35.
            Without any JD, resume-only mode uses quality 60 / skill breadth 25 / keyword richness 15.
          </p>
        </GlassCard>
      </div>

      {/* API + honesty */}
      <div className="mx-auto mt-6 grid max-w-4xl gap-5 lg:grid-cols-2">
        <GlassCard className="p-6">
          <div className="flex items-center gap-2.5">
            <Braces size={18} className="text-cyan-500" />
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">One endpoint, structured JSON</h3>
          </div>
          <div className="mt-4 overflow-x-auto rounded-xl bg-slate-900 px-4 py-3.5 font-mono text-xs leading-relaxed text-slate-300 dark:bg-black/40">
            <p><span className="text-emerald-400">POST</span> /api/analyze</p>
            <p className="text-slate-500">multipart/form-data:</p>
            <p>&nbsp;&nbsp;resume<span className="text-slate-500">:</span> file (pdf|docx|txt)</p>
            <p>&nbsp;&nbsp;job_description<span className="text-slate-500">:</span> string?</p>
            <p className="mt-2 text-slate-500">→ {'{'} overall_score, skills, matched_skills,</p>
            <p className="text-slate-500">&nbsp;&nbsp;missing_skills, sections, recommendations… {'}'}</p>
          </div>
        </GlassCard>
        <GlassCard className="p-6">
          <div className="flex items-center gap-2.5">
            <CircleAlert size={18} className="text-amber-500" />
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">Honest by design</h3>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-slate-500 dark:text-slate-400">
            Textual similarity is a proxy — real hiring pipelines weigh experience, referrals and conversation too. This
            tool never claims a score guarantees ATS success, and it never suggests adding skills or keywords that don't
            truthfully represent you.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-slate-500 dark:text-slate-400">
            Recommendations always frame gaps as opportunities: build the skill, then earn the keyword.
          </p>
        </GlassCard>
      </div>

      <div className="mt-14 text-center">
        <Link
          to="/analyzer"
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-500 px-8 py-3.5 text-sm font-bold text-white shadow-xl shadow-violet-600/25 transition-all hover:brightness-110"
        >
          Run the pipeline on your resume <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}
