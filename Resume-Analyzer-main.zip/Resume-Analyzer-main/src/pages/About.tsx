import { Link } from 'react-router-dom';
import { ArrowRight, Brain, Database, FileCode2, Layers, Server, ShieldCheck, Telescope } from 'lucide-react';
import { GlassCard, PageHeader } from '../components/ui';

const STACK = [
  {
    icon: Layers,
    title: 'Frontend',
    items: ['React 19 + Vite + TypeScript', 'Tailwind CSS v4 + glassmorphism', 'Recharts data visualization', 'Framer Motion animations', 'Lucide icon system'],
  },
  {
    icon: Server,
    title: 'Backend',
    items: ['Python · FastAPI + Pydantic', 'Uvicorn ASGI server', 'Multipart parsing, strict validation', 'CORS + in-memory processing', 'Mirrored Node serverless route for the hosted demo'],
  },
  {
    icon: Brain,
    title: 'NLP & ML',
    items: ['Scikit-Learn TF-IDF + cosine similarity', 'Regex/NLTK-style normalization', '60+ skill dictionary with aliases', 'Section detection + quality heuristics'],
  },
  {
    icon: Database,
    title: 'Data Policy',
    items: ['No persistence — zero storage', 'In-memory buffers only', '5 MB upload ceiling', 'Nothing trained on your data'],
  },
];

const ISNT = [
  'A black-box ATS simulator promising guaranteed pass-rates',
  'A place that stores, sells or trains on your resume',
  'A keyword-stuffing coach',
];
const IS = [
  'A transparent alignment estimate with visible math',
  'A gap analysis you turn into a learning plan',
  'A portfolio-ready demo of NLP + ML + full-stack engineering',
];

const FUTURE = [
  'spaCy NER for company/degree extraction',
  'Sentence-embedding similarity (SBERT) alongside TF-IDF',
  'Multi-JD comparison and saved history',
  'Exportable PDF report',
];

export default function About() {
  return (
    <div className="mx-auto max-w-7xl px-4 pt-16 pb-8 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="About the Project"
        title={
          <>
            Built to make resume feedback <span className="text-gradient">measurable</span>
          </>
        }
        subtitle="AlignAI is a full-stack demonstration of applied NLP: classic information-retrieval technique (TF-IDF + cosine similarity) combined with a curated skill ontology and honest, explainable scoring — wrapped in a product-grade UI."
      />

      {/* stack */}
      <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {STACK.map((s) => (
          <GlassCard key={s.title} className="p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600/15 to-cyan-500/15 text-violet-600 dark:text-violet-300">
              <s.icon size={20} />
            </span>
            <h3 className="font-display mt-4 text-base font-bold text-slate-900 dark:text-white">{s.title}</h3>
            <ul className="mt-3 space-y-1.5">
              {s.items.map((i) => (
                <li key={i} className="text-xs leading-relaxed text-slate-500 dark:text-slate-400">· {i}</li>
              ))}
            </ul>
          </GlassCard>
        ))}
      </div>

      {/* is / isn't */}
      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <GlassCard className="p-7">
          <div className="flex items-center gap-2.5">
            <ShieldCheck size={18} className="text-emerald-500" />
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">What this tool is</h3>
          </div>
          <ul className="mt-4 space-y-2.5">
            {IS.map((t) => (
              <li key={t} className="flex items-start gap-2.5 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" /> {t}
              </li>
            ))}
          </ul>
        </GlassCard>
        <GlassCard className="p-7">
          <div className="flex items-center gap-2.5">
            <FileCode2 size={18} className="text-rose-500" />
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">What it deliberately is not</h3>
          </div>
          <ul className="mt-4 space-y-2.5">
            {ISNT.map((t) => (
              <li key={t} className="flex items-start gap-2.5 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-rose-400" /> {t}
              </li>
            ))}
          </ul>
        </GlassCard>
      </div>

      {/* roadmap */}
      <GlassCard className="mt-6 p-7">
        <div className="flex items-center gap-2.5">
          <Telescope size={18} className="text-cyan-500" />
          <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Future improvements</h3>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {FUTURE.map((f) => (
            <div key={f} className="rounded-xl border border-slate-200/70 bg-white/50 px-4 py-3 text-sm text-slate-600 dark:border-white/[0.07] dark:bg-white/[0.02] dark:text-slate-300">
              {f}
            </div>
          ))}
        </div>
      </GlassCard>

      <div className="mt-14 text-center">
        <Link
          to="/analyzer"
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-500 px-8 py-3.5 text-sm font-bold text-white shadow-xl shadow-violet-600/25 transition-all hover:brightness-110"
        >
          Try the analyzer <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}
