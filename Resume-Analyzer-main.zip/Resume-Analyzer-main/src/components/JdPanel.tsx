import { ClipboardPaste, Eraser, Sparkles } from 'lucide-react';
import { SAMPLE_JD } from '../lib/sample';

interface Props {
  value: string;
  disabled?: boolean;
  onChange: (v: string) => void;
}

export default function JdPanel({ value, disabled, onChange }: Props) {
  const chars = value.length;
  const words = value.trim() ? value.trim().split(/\s+/).length : 0;

  return (
    <div className="flex h-full flex-col">
      <div className="mb-2.5 flex items-center justify-between gap-2">
        <label htmlFor="jd" className="text-sm font-semibold text-slate-800 dark:text-slate-100">
          Job Description <span className="ml-1 text-xs font-medium text-slate-400">(optional)</span>
        </label>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={disabled}
            onClick={() => onChange(SAMPLE_JD)}
            className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:border-violet-300 hover:text-violet-600 disabled:opacity-50 dark:border-white/10 dark:text-slate-300 dark:hover:border-violet-400/40 dark:hover:text-violet-300"
          >
            <Sparkles size={12} /> Example JD
          </button>
          <button
            type="button"
            disabled={disabled || !value}
            onClick={() => onChange('')}
            className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:border-rose-300 hover:text-rose-500 disabled:opacity-50 dark:border-white/10 dark:text-slate-300 dark:hover:border-rose-400/40"
          >
            <Eraser size={12} /> Clear
          </button>
        </div>
      </div>
      <div className="relative flex-1">
        <textarea
          id="jd"
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Paste the target job description here…\n\nWith a JD, AlignAI computes skill gaps, keyword coverage and TF–IDF similarity against the role. Without one, it runs a resume-quality analysis instead."
          className="h-full min-h-[190px] w-full resize-none rounded-2xl border border-slate-300 bg-white/60 px-4 py-3.5 text-sm leading-relaxed text-slate-700 placeholder:text-slate-400 focus:border-violet-400 focus:ring-2 focus:ring-violet-500/20 focus:outline-none disabled:opacity-60 dark:border-white/15 dark:bg-white/[0.03] dark:text-slate-200 dark:placeholder:text-slate-500"
          spellCheck={false}
        />
        <div className="pointer-events-none absolute right-3 bottom-2.5 rounded-md bg-white/80 px-2 py-0.5 text-[11px] font-medium text-slate-400 tabular-nums backdrop-blur dark:bg-transparent dark:text-slate-500">
          {words} words · {chars.toLocaleString()} chars
        </div>
      </div>
      <p className="mt-2 flex items-center gap-1.5 text-xs text-slate-400 dark:text-slate-500">
        <ClipboardPaste size={12} className="shrink-0" />
        Matching activates automatically when the JD is 10+ words.
      </p>
    </div>
  );
}
