import { motion } from 'framer-motion';
import { RefreshCcw } from 'lucide-react';
import type { AnalysisResponse } from '../lib/types';
import SummaryCard from './results/SummaryCard';
import ScoreGauges from './results/ScoreGauges';
import SkillsPanel from './results/SkillsPanel';
import KeywordsPanel from './results/KeywordsPanel';
import SectionsPanel from './results/SectionsPanel';
import ChartsPanel from './results/ChartsPanel';
import RecommendationsPanel from './results/RecommendationsPanel';

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

export default function ResultsDashboard({ data, onReset }: { data: AnalysisResponse; onReset: () => void }) {
  return (
    <div className="mt-12 space-y-5">
      <Reveal>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            Your <span className="text-gradient">Analysis</span>
          </h2>
          <button
            onClick={onReset}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white/70 px-4 py-2 text-sm font-semibold text-slate-600 transition-colors hover:border-violet-400 hover:text-violet-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:border-violet-400/50 dark:hover:text-violet-300"
          >
            <RefreshCcw size={15} /> Analyze Another Resume
          </button>
        </div>
      </Reveal>

      <Reveal delay={0.05}>
        <SummaryCard data={data} />
      </Reveal>

      <Reveal delay={0.1}>
        <ScoreGauges data={data} />
      </Reveal>

      <Reveal delay={0.15}>
        <div className="grid gap-5 xl:grid-cols-2">
          <SkillsPanel data={data} />
          <KeywordsPanel data={data} />
        </div>
      </Reveal>

      <Reveal delay={0.2}>
        <ChartsPanel data={data} />
      </Reveal>

      <Reveal delay={0.25}>
        <SectionsPanel data={data} />
      </Reveal>

      <Reveal delay={0.3}>
        <RecommendationsPanel data={data} />
      </Reveal>

      <Reveal delay={0.35}>
        <p className="rounded-2xl border border-slate-200/70 bg-white/50 px-5 py-4 text-center text-xs leading-relaxed text-slate-400 dark:border-white/[0.07] dark:bg-white/[0.02] dark:text-slate-500">
          {data.meta.disclaimer}
        </p>
      </Reveal>
    </div>
  );
}
