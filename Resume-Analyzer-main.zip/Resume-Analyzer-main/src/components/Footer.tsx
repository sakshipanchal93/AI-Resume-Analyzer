import { FileSearch, Github } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="relative z-10 mt-24 border-t border-slate-200/70 dark:border-white/[0.06]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-8 md:flex-row md:items-center">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 via-indigo-500 to-cyan-400 text-white">
              <FileSearch size={18} />
            </span>
            <div>
              <p className="font-display text-sm font-bold text-slate-900 dark:text-white">AlignAI — Resume Analyzer</p>
              <p className="text-xs text-slate-400 dark:text-slate-500">NLP · TF-IDF · Cosine Similarity · FastAPI · React</p>
            </div>
          </div>
          <nav className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-500 dark:text-slate-400">
            <Link to="/" className="hover:text-violet-600 dark:hover:text-violet-300">Home</Link>
            <Link to="/analyzer" className="hover:text-violet-600 dark:hover:text-violet-300">Analyzer</Link>
            <Link to="/features" className="hover:text-violet-600 dark:hover:text-violet-300">Features</Link>
            <Link to="/how-it-works" className="hover:text-violet-600 dark:hover:text-violet-300">How It Works</Link>
            <Link to="/about" className="hover:text-violet-600 dark:hover:text-violet-300">About</Link>
            <span className="inline-flex items-center gap-1.5 text-slate-400 dark:text-slate-500">
              <Github size={14} /> Open-source demo
            </span>
          </nav>
        </div>
        <div className="mt-8 border-t border-slate-200/60 pt-6 dark:border-white/[0.06]">
          <p className="text-xs leading-relaxed text-slate-400 dark:text-slate-500">
            Uploaded resumes are processed in memory and are never stored. Scores estimate textual alignment and document
            completeness using transparent, deterministic NLP heuristics — they do not guarantee ATS success, recruiter
            decisions, or hiring outcomes.
          </p>
        </div>
      </div>
    </footer>
  );
}
