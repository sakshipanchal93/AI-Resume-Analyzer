export default function Backdrop() {
  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden>
      {/* soft gradient orbs */}
      <div className="animate-drift absolute -top-40 -left-40 h-[34rem] w-[34rem] rounded-full bg-violet-500/25 blur-[130px] dark:bg-violet-600/[0.16]" />
      <div className="animate-drift absolute top-1/3 -right-52 h-[30rem] w-[30rem] rounded-full bg-cyan-400/20 blur-[130px] [animation-delay:-6s] dark:bg-cyan-500/[0.10]" />
      <div className="absolute bottom-0 left-1/3 h-[26rem] w-[26rem] rounded-full bg-indigo-400/15 blur-[130px] dark:bg-indigo-600/[0.10]" />
      {/* grid texture */}
      <div className="absolute inset-0 opacity-[0.35] dark:opacity-[0.18] [background-image:linear-gradient(to_right,rgba(100,116,139,0.10)_1px,transparent_1px),linear-gradient(to_bottom,rgba(100,116,139,0.10)_1px,transparent_1px)] [background-size:56px_56px] [mask-image:radial-gradient(ellipse_at_top,black_20%,transparent_70%)]" />
    </div>
  );
}
