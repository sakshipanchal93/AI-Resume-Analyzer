import { useRef, useState } from 'react';
import type { DragEvent } from 'react';
import { CheckCircle2, FileText, FileUp, X } from 'lucide-react';
import { formatBytes, validateResumeFile } from '../lib/api';

interface Props {
  file: File | null;
  error: string | null;
  disabled?: boolean;
  onSelect: (file: File) => void;
  onRemove: () => void;
  onError: (msg: string | null) => void;
}

export default function Dropzone({ file, error, disabled, onSelect, onRemove, onError }: Props) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const dragDepth = useRef(0);

  const handleFile = (f?: File | null) => {
    if (!f || disabled) return;
    const err = validateResumeFile(f);
    if (err) {
      onError(err);
      onRemove();
      return;
    }
    onError(null);
    onSelect(f);
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    dragDepth.current = 0;
    setDragging(false);
    if (disabled) return;
    handleFile(e.dataTransfer.files?.[0]);
  };

  const ext = file ? file.name.split('.').pop()?.toUpperCase() : '';

  return (
    <div>
      <div
        onDragEnter={(e) => {
          e.preventDefault();
          dragDepth.current += 1;
          if (!disabled) setDragging(true);
        }}
        onDragLeave={(e) => {
          e.preventDefault();
          dragDepth.current -= 1;
          if (dragDepth.current <= 0) setDragging(false);
        }}
        onDragOver={(e) => e.preventDefault()}
        onDrop={onDrop}
        onClick={() => !disabled && !file && inputRef.current?.click()}
        role="button"
        aria-label="Upload resume"
        className={`group relative flex min-h-[190px] flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-8 text-center transition-all duration-200 ${
          disabled ? 'cursor-not-allowed opacity-60' : file ? 'cursor-default' : 'cursor-pointer'
        } ${
          dragging
            ? 'scale-[1.01] border-violet-500 bg-violet-500/10 shadow-lg shadow-violet-500/10 dark:bg-violet-400/10'
            : error
              ? 'border-rose-400/60 bg-rose-500/[0.04] dark:border-rose-500/40'
              : file
                ? 'border-emerald-500/40 bg-emerald-500/[0.04] dark:bg-emerald-400/[0.05]'
                : 'border-slate-300 hover:border-violet-400 hover:bg-violet-500/[0.04] dark:border-white/15 dark:hover:border-violet-400/60 dark:hover:bg-violet-400/[0.06]'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,.docx,.txt,application/pdf,text/plain,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          className="hidden"
          onChange={(e) => {
            handleFile(e.target.files?.[0]);
            e.target.value = '';
          }}
        />

        {!file ? (
          <>
            <span
              className={`mb-4 flex h-14 w-14 items-center justify-center rounded-2xl transition-all ${
                dragging
                  ? 'scale-110 bg-gradient-to-br from-violet-600 to-indigo-500 text-white shadow-lg shadow-violet-600/30'
                  : 'bg-violet-500/10 text-violet-600 group-hover:scale-105 dark:text-violet-300'
              }`}
            >
              <FileUp size={26} />
            </span>
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">
              {dragging ? 'Drop your resume here' : 'Drag & drop your resume'}
            </p>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              or <span className="font-semibold text-violet-600 dark:text-violet-300">browse files</span> from your device
            </p>
            <p className="mt-3 text-xs font-medium tracking-wide text-slate-400 uppercase dark:text-slate-500">
              PDF · DOCX · TXT — up to 5 MB
            </p>
          </>
        ) : (
          <div className="flex w-full items-center gap-3 text-left">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-400 text-white shadow-lg shadow-emerald-500/20">
              <FileText size={22} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{file.name}</p>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span className="rounded-md bg-slate-100 px-1.5 py-0.5 font-bold text-slate-600 dark:bg-white/10 dark:text-slate-300">{ext}</span>
                <span>{formatBytes(file.size)}</span>
                <span className="inline-flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 size={13} /> Ready to analyze
                </span>
              </div>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
              disabled={disabled}
              aria-label="Remove file"
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 text-slate-400 transition-colors hover:border-rose-300 hover:bg-rose-50 hover:text-rose-500 disabled:opacity-50 dark:border-white/10 dark:hover:border-rose-500/40 dark:hover:bg-rose-500/10"
            >
              <X size={15} />
            </button>
          </div>
        )}
      </div>
      {error && <p className="mt-2.5 text-sm font-medium text-rose-500 dark:text-rose-400">{error}</p>}
    </div>
  );
}
