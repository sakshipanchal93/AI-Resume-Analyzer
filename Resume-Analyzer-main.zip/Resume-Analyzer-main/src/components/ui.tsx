import type { ReactNode } from 'react';
import { Info } from 'lucide-react';

export function GlassCard({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`glass rounded-2xl ${className}`}>{children}</div>;
}

export function PageHeader({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: string;
}) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      {eyebrow && (
        <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-violet-500/25 bg-violet-500/10 px-3.5 py-1 text-xs font-semibold tracking-wide text-violet-700 uppercase dark:text-violet-300">
          {eyebrow}
        </span>
      )}
      <h1 className="font-display text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl lg:text-[2.75rem] lg:leading-[1.15] dark:text-white">
        {title}
      </h1>
      {subtitle && <p className="mt-4 text-base leading-relaxed text-slate-500 sm:text-lg dark:text-slate-400">{subtitle}</p>}
    </div>
  );
}

/** Hover/focus tooltip — explain scores without clutter. */
export function Tooltip({ content, wide = false }: { content: ReactNode; wide?: boolean }) {
  return (
    <span className="group/tt relative inline-flex items-center align-middle">
      <Info size={14} className="cursor-help text-slate-400 transition-colors hover:text-violet-500 dark:text-slate-500" />
      <span
        className={`pointer-events-none absolute bottom-full left-1/2 z-50 mb-2 -translate-x-1/2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs leading-relaxed font-normal text-slate-600 opacity-0 shadow-xl transition-all duration-150 group-hover/tt:opacity-100 group-focus-within/tt:opacity-100 dark:border-white/10 dark:bg-[#141a2e] dark:text-slate-300 ${
          wide ? 'w-72 sm:w-80' : 'w-56'
        }`}
      >
        {content}
      </span>
    </span>
  );
}

const PRIORITY_STYLES = {
  high: 'bg-rose-500/10 text-rose-600 border-rose-500/30 dark:text-rose-300',
  medium: 'bg-amber-500/10 text-amber-600 border-amber-500/30 dark:text-amber-300',
  low: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30 dark:text-emerald-300',
} as const;

export function PriorityBadge({ priority }: { priority: 'high' | 'medium' | 'low' }) {
  return (
    <span className={`inline-flex shrink-0 items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold tracking-wider uppercase ${PRIORITY_STYLES[priority]}`}>
      {priority}
    </span>
  );
}

export function scoreTone(score: number | null): { text: string; ring: string; gradient: [string, string] } {
  if (score === null) return { text: 'text-slate-400', ring: 'stroke-slate-300 dark:stroke-slate-700', gradient: ['#94a3b8', '#64748b'] };
  if (score >= 70) return { text: 'text-emerald-500 dark:text-emerald-400', ring: 'stroke-emerald-500', gradient: ['#10b981', '#34d399'] };
  if (score >= 45) return { text: 'text-amber-500 dark:text-amber-400', ring: 'stroke-amber-500', gradient: ['#f59e0b', '#fbbf24'] };
  return { text: 'text-rose-500 dark:text-rose-400', ring: 'stroke-rose-500', gradient: ['#f43f5e', '#fb7185'] };
}
