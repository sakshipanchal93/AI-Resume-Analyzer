import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { GlassCard } from '../ui';
import { useTheme } from '../../hooks/useTheme';
import type { AnalysisResponse } from '../../lib/types';

const BAR_COLORS = ['#8b5cf6', '#6366f1', '#0ea5e9', '#22d3ee', '#10b981', '#f59e0b', '#f43f5e'];

export default function ChartsPanel({ data }: { data: AnalysisResponse }) {
  const { isDark } = useTheme();
  const gridColor = isDark ? 'rgba(148,163,184,0.15)' : 'rgba(100,116,139,0.25)';
  const tickColor = isDark ? '#94a3b8' : '#64748b';
  const tooltipStyle = {
    backgroundColor: isDark ? '#101626' : '#ffffff',
    border: `1px solid ${isDark ? 'rgba(148,163,184,0.2)' : '#e2e8f0'}`,
    borderRadius: 12,
    fontSize: 12,
    color: isDark ? '#e2e8f0' : '#334155',
  } as const;
  const targetLabel = data.meta.mode === 'job_match' ? 'Job Requirement' : 'Strong Benchmark';

  return (
    <div className="grid gap-4 lg:grid-cols-5">
      <GlassCard className="p-6 lg:col-span-3">
        <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Resume vs Job Requirements</h3>
        <p className="mt-1 mb-2 text-sm text-slate-500 dark:text-slate-400">
          Six-dimension comparison of your document against {data.meta.mode === 'job_match' ? "the role's expectations" : 'a strong-resume benchmark'}.
        </p>
        <div className="h-[320px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={data.charts.radar} outerRadius="72%">
              <PolarGrid stroke={gridColor} />
              <PolarAngleAxis dataKey="dimension" tick={{ fill: tickColor, fontSize: 11, fontWeight: 600 }} />
              <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
              <Radar
                name="Your Resume"
                dataKey="resume"
                stroke="#8b5cf6"
                fill="#8b5cf6"
                fillOpacity={0.32}
                strokeWidth={2}
                isAnimationActive
              />
              <Radar
                name={targetLabel}
                dataKey="target"
                stroke="#22d3ee"
                fill="#22d3ee"
                fillOpacity={0.06}
                strokeWidth={1.6}
                strokeDasharray="5 4"
                isAnimationActive
              />
              <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
              <RTooltip contentStyle={tooltipStyle} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </GlassCard>

      <GlassCard className="p-6 lg:col-span-2">
        <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Skill Distribution</h3>
        <p className="mt-1 mb-2 text-sm text-slate-500 dark:text-slate-400">
          {data.skills.length} detected skills, grouped by category.
        </p>
        <div className="h-[320px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.charts.skill_distribution} layout="vertical" margin={{ left: 8, right: 20, top: 4, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} horizontal={false} />
              <XAxis type="number" allowDecimals={false} tick={{ fill: tickColor, fontSize: 11 }} />
              <YAxis
                type="category"
                dataKey="category"
                width={128}
                tick={{ fill: tickColor, fontSize: 11, fontWeight: 600 }}
              />
              <RTooltip contentStyle={tooltipStyle} cursor={{ fill: isDark ? 'rgba(148,163,184,0.08)' : 'rgba(100,116,139,0.08)' }} />
              <Bar dataKey="count" name="Skills" radius={[0, 8, 8, 0]} barSize={18} isAnimationActive>
                {data.charts.skill_distribution.map((entry, i) => (
                  <Cell key={entry.category} fill={BAR_COLORS[i % BAR_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </GlassCard>
    </div>
  );
}
