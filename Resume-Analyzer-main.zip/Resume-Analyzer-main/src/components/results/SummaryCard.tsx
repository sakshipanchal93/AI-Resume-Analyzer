import { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Copy, FileText, FlaskConical, Timer, Type } from 'lucide-react';
import { GlassCard } from '../ui';
import type { AnalysisResponse } from '../../lib/types';

export default function SummaryCard({ data }: { data: AnalysisResponse }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(data.summary);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard unavailable */
    }
  };

  return (
    <GlassCard className="relative overflow-hidden p-6">
      <div className="pointer-events-none absolute -top-20 -right-20 h-56 w-56 rounded-full bg-violet-500/10 blur-3xl" />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Analysis Summary</h3>
        <div className="flex flex-wrap items-center gap-2">
          {data.meta.demo && (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 px-3 py-1 text-[11px] font-bold tracking-wider text-amber-600 uppercase dark:text-amber-300">
              <FlaskConical size={11} /> Demo Data
            </span>
          )}
          <span className="rounded-full border border-slate-200 bg-slate-100 px-3 py-1 text-[11px] font-semibold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
            {data.meta.mode === 'job_match' ? 'Job Match Analysis' : 'Resume Quality Analysis'}
          </span>
          <button
            onClick={copy}
            className="inline-flex items-center gap-1.5 rounded-full border border-violet-500/30 bg-violet-500/10 px-3 py-1 text-[11px] font-bold text-violet-700 transition-colors hover:bg-violet-500/20 dark:text-violet-300"
          >
            {copied ? <Check size={12} /> : <Copy size={12} />}
            {copied ? 'Copied' : 'Copy summary'}
          </button>
        </div>
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="mt-4 text-sm leading-relaxed text-slate-600 sm:text-[15px] dark:text-slate-300"
      >
        {data.summary}
      </motion.p>

      <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-slate-200/70 pt-4 text-xs text-slate-400 dark:border-white/[0.07] dark:text-slate-500">
        <span className="inline-flex items-center gap-1.5"><FileText size={13} /> {data.meta.file_name}</span>
        <span className="inline-flex items-center gap-1.5"><Type size={13} /> {data.meta.word_count} words</span>
        <span className="inline-flex items-center gap-1.5"><Timer size={13} /> analyzed in {Math.max(data.meta.processing_ms, 1)} ms</span>
      </div>
    </GlassCard>
  );
}
