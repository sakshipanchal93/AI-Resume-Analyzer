import { motion } from 'framer-motion';
import { Check, CircleAlert } from 'lucide-react';
import { GlassCard } from '../ui';
import type { AnalysisResponse } from '../../lib/types';

function Chip({ label, variant }: { label: string; variant: 'matched' | 'missing' | 'neutral' }) {
  const styles =
    variant === 'matched'
      ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
      : variant === 'missing'
        ? 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300'
        : 'border-violet-500/25 bg-violet-500/10 text-violet-700 dark:text-violet-300';
  return (
    <motion.span
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.25 }}
      className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-xs font-semibold ${styles}`}
    >
      {variant === 'matched' && <Check size={11} strokeWidth={3} />}
      {label}
    </motion.span>
  );
}

export default function SkillsPanel({ data }: { data: AnalysisResponse }) {
  const isJob = data.meta.mode === 'job_match';
  const ratio = data.skill_match_ratio;
  const pct = ratio && ratio.required > 0 ? Math.round((ratio.matched / ratio.required) * 100) : null;

  return (
    <GlassCard className="p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
          {isJob ? 'Skill Match' : 'Detected Skill Profile'}
        </h3>
        {ratio && (
          <span className="text-sm font-semibold text-slate-500 dark:text-slate-400">
            <span className="text-gradient font-display text-xl font-bold">{ratio.matched}</span>
            <span className="mx-1">/</span>
            {ratio.required} required skills
          </span>
        )}
      </div>

      {ratio && pct !== null && (
        <div className="mt-4">
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${pct}%` }}
              transition={{ duration: 1.1, ease: 'easeOut', delay: 0.2 }}
              className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400"
            />
          </div>
          <p className="mt-1.5 text-xs text-slate-400 dark:text-slate-500">{pct}% of JD skills found in your resume</p>
        </div>
      )}

      {isJob && (
        <div className="mt-5 space-y-4">
          {data.matched_skills.length > 0 && (
            <div>
              <p className="mb-2 text-xs font-bold tracking-wider text-emerald-600 uppercase dark:text-emerald-400">
                Matched skills ({data.matched_skills.length})
              </p>
              <div className="flex flex-wrap gap-1.5">
                {data.matched_skills.map((s) => (
                  <Chip key={s} label={s} variant="matched" />
                ))}
              </div>
            </div>
          )}
          {data.missing_skills.length > 0 && (
            <div>
              <p className="mb-2 text-xs font-bold tracking-wider text-amber-600 uppercase dark:text-amber-400">
                Missing skills ({data.missing_skills.length})
              </p>
              <div className="flex flex-wrap gap-1.5">
                {data.missing_skills.map((s) => (
                  <Chip key={s} label={s} variant="missing" />
                ))}
              </div>
            </div>
          )}
          {data.jd_skills.length === 0 && (
            <p className="text-sm text-slate-500 dark:text-slate-400">
              No skills from the dictionary were detected in this job description — scoring fell back to keyword and
              similarity analysis.
            </p>
          )}
          <p className="flex items-start gap-1.5 rounded-xl bg-amber-500/[0.07] px-3.5 py-2.5 text-xs leading-relaxed text-amber-700 dark:bg-amber-400/[0.06] dark:text-amber-300/90">
            <CircleAlert size={14} className="mt-0.5 shrink-0" />
            <span>
              Only add skills to your resume that genuinely represent your experience. Misrepresentation is easy to
              expose in interviews — use the gaps as a learning roadmap instead.
            </span>
          </p>
        </div>
      )}

      {!isJob && (
        <div className="mt-4">
          <p className="mb-2 text-xs font-bold tracking-wider text-violet-600 uppercase dark:text-violet-300">
            {data.skills.length} skills detected in your resume
          </p>
          <div className="flex flex-wrap gap-1.5">
            {data.skills.map((s) => (
              <Chip key={s} label={s} variant="neutral" />
            ))}
          </div>
          <p className="mt-3 text-xs text-slate-400 dark:text-slate-500">
            Paste a job description to compare this profile against a specific role's requirements.
          </p>
        </div>
      )}

      {isJob && data.skills.length > 0 && (
        <div className="mt-5 border-t border-slate-200 pt-4 dark:border-white/[0.07]">
          <p className="mb-2 text-xs font-bold tracking-wider text-violet-600 uppercase dark:text-violet-300">
            All {data.skills.length} skills found in your resume
          </p>
          <div className="flex flex-wrap gap-1.5">
            {data.skills.map((s) => (
              <Chip key={s} label={s} variant="neutral" />
            ))}
          </div>
        </div>
      )}
    </GlassCard>
  );
}
