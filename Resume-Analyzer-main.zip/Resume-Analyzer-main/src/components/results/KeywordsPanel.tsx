import { CheckCircle2, CircleAlert, XCircle } from 'lucide-react';
import { GlassCard } from '../ui';
import type { AnalysisResponse } from '../../lib/types';

export default function KeywordsPanel({ data }: { data: AnalysisResponse }) {
  const isJob = data.meta.mode === 'job_match';

  if (!isJob) {
    return (
      <GlassCard className="p-6">
        <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Top Resume Keywords</h3>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Highest-signal terms detected in your resume (frequency × specificity, stopwords removed).
        </p>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {data.resume_top_keywords.map((k) => (
            <span
              key={k}
              className="rounded-lg border border-cyan-500/25 bg-cyan-500/10 px-2.5 py-1 text-xs font-semibold text-cyan-700 dark:text-cyan-300"
            >
              {k}
            </span>
          ))}
        </div>
        <p className="mt-4 text-xs text-slate-400 dark:text-slate-500">
          Add a job description to see which JD keywords you cover — and which you miss.
        </p>
      </GlassCard>
    );
  }

  return (
    <GlassCard className="p-6">
      <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">JD Keyword Coverage</h3>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
        The {data.jd_keywords.length} highest-signal keywords in this job description, checked against your resume.
      </p>

      <div className="mt-5 grid gap-5 sm:grid-cols-2">
        <div>
          <p className="mb-2.5 inline-flex items-center gap-1.5 text-xs font-bold tracking-wider text-emerald-600 uppercase dark:text-emerald-400">
            <CheckCircle2 size={13} /> Found ({data.keywords.length})
          </p>
          <div className="flex flex-wrap gap-1.5">
            {data.keywords.length ? (
              data.keywords.map((k) => (
                <span key={k} className="rounded-lg border border-emerald-500/25 bg-emerald-500/10 px-2.5 py-1 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                  {k}
                </span>
              ))
            ) : (
              <p className="text-xs text-slate-400">None of the top JD keywords appear in the resume yet.</p>
            )}
          </div>
        </div>
        <div>
          <p className="mb-2.5 inline-flex items-center gap-1.5 text-xs font-bold tracking-wider text-rose-500 uppercase dark:text-rose-400">
            <XCircle size={13} /> Missing ({data.missing_keywords.length})
          </p>
          <div className="flex flex-wrap gap-1.5">
            {data.missing_keywords.length ? (
              data.missing_keywords.map((k) => (
                <span key={k} className="rounded-lg border border-rose-500/25 bg-rose-500/10 px-2.5 py-1 text-xs font-semibold text-rose-600 dark:text-rose-300">
                  {k}
                </span>
              ))
            ) : (
              <p className="text-xs text-slate-400">Excellent — no top keyword gaps detected.</p>
            )}
          </div>
        </div>
      </div>

      <p className="mt-5 flex items-start gap-1.5 rounded-xl bg-amber-500/[0.07] px-3.5 py-2.5 text-xs leading-relaxed text-amber-700 dark:bg-amber-400/[0.06] dark:text-amber-300/90">
        <CircleAlert size={14} className="mt-0.5 shrink-0" />
        <span>
          Only incorporate keywords that genuinely describe your experience. ATS systems and interviewers both penalize
          keyword-stuffing — relevance beats coverage.
        </span>
      </p>
    </GlassCard>
  );
}
