import { useEffect, useState } from 'react';

const STEPS = [
  'Extracting text from your resume…',
  'Normalizing text & detecting sections…',
  'Extracting skills from the 60+ skill dictionary…',
  'Vectorizing with TF-IDF & computing cosine similarity…',
  'Scoring, ranking gaps & writing recommendations…',
];

function Bone({ className }: { className: string }) {
  return <div className={`animate-pulse rounded-xl bg-slate-200/80 dark:bg-white/[0.07] ${className}`} />;
}

export default function AnalysisSkeleton() {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setStep((s) => (s + 1) % STEPS.length), 1400);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="mt-10 space-y-6" aria-live="polite">
      <div className="glass flex flex-col items-center gap-3 rounded-2xl px-6 py-6 text-center">
        <div className="relative flex h-12 w-12 items-center justify-center">
          <span className="absolute inset-0 animate-ping rounded-full bg-violet-500/30" />
          <span className="relative flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-violet-600 to-indigo-500 text-white shadow-lg shadow-violet-600/30">
            <svg className="h-5 w-5 animate-spin" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
            </svg>
          </span>
        </div>
        <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{STEPS[step]}</p>
        <div className="flex gap-1.5">
          {STEPS.map((_, i) => (
            <span
              key={i}
              className={`h-1.5 rounded-full transition-all duration-300 ${i === step ? 'w-6 bg-violet-500' : i < step ? 'w-1.5 bg-violet-400/60' : 'w-1.5 bg-slate-300 dark:bg-white/15'}`}
            />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="glass flex flex-col items-center gap-4 rounded-2xl px-4 py-7">
            <Bone className="h-24 w-24 !rounded-full" />
            <Bone className="h-3.5 w-24" />
          </div>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="glass space-y-3 rounded-2xl p-6">
          <Bone className="h-4 w-40" />
          <Bone className="h-56 w-full" />
        </div>
        <div className="glass space-y-3 rounded-2xl p-6">
          <Bone className="h-4 w-40" />
          <Bone className="h-56 w-full" />
        </div>
      </div>
      <div className="glass space-y-3 rounded-2xl p-6">
        <Bone className="h-4 w-52" />
        <Bone className="h-3 w-full" />
        <Bone className="h-3 w-5/6" />
        <Bone className="h-3 w-2/3" />
      </div>
    </div>
  );
}
