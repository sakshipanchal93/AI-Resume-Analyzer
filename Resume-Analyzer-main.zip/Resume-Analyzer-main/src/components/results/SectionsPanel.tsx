import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import { GlassCard } from '../ui';
import type { AnalysisResponse, SectionStatus } from '../../lib/types';

const META: Record<SectionStatus, { label: string; icon: typeof CheckCircle2; cls: string }> = {
  present: { label: 'Present', icon: CheckCircle2, cls: 'text-emerald-500 dark:text-emerald-400' },
  attention: { label: 'Needs Attention', icon: AlertTriangle, cls: 'text-amber-500 dark:text-amber-400' },
  missing: { label: 'Missing', icon: XCircle, cls: 'text-rose-500 dark:text-rose-400' },
};

export default function SectionsPanel({ data }: { data: AnalysisResponse }) {
  return (
    <GlassCard className="p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Resume Completeness</h3>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">8-section structural audit of your document.</p>
        </div>
        <div className="text-right">
          <span className="font-display text-3xl font-bold text-slate-900 tabular-nums dark:text-white">
            {data.completeness_score}<span className="text-base text-slate-400">%</span>
          </span>
          <p className="text-[10px] font-bold tracking-widest text-slate-400 uppercase dark:text-slate-500">Complete</p>
        </div>
      </div>

      <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${data.completeness_score}%` }}
          transition={{ duration: 1.1, ease: 'easeOut', delay: 0.2 }}
          className="h-full rounded-full bg-gradient-to-r from-violet-500 via-indigo-500 to-cyan-400"
        />
      </div>

      <ul className="mt-5 grid gap-2 sm:grid-cols-2">
        {data.sections.map((s, i) => {
          const m = META[s.status];
          const Icon = m.icon;
          return (
            <motion.li
              key={s.key}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i, duration: 0.35 }}
              className="flex items-start gap-3 rounded-xl border border-slate-200/70 bg-white/50 px-3.5 py-3 dark:border-white/[0.07] dark:bg-white/[0.02]"
            >
              <Icon size={17} className={`mt-0.5 shrink-0 ${m.cls}`} />
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold text-slate-800 dark:text-slate-100">{s.label}</span>
                  <span className={`text-[10px] font-bold tracking-wider uppercase ${m.cls}`}>{m.label}</span>
                </div>
                <p className="mt-0.5 text-xs leading-relaxed text-slate-500 dark:text-slate-400">{s.detail}</p>
              </div>
            </motion.li>
          );
        })}
      </ul>
    </GlassCard>
  );
}
