import Gauge from '../Gauge';
import { GlassCard, Tooltip } from '../ui';
import type { AnalysisResponse } from '../../lib/types';

const TIP_OVERALL = (
  <span>
    Weighted blend of the other scores: <b>30% skill match · 25% keyword match · 20% TF-IDF cosine similarity · 25%
    resume quality</b> (weights adapt when no JD is given). It estimates textual alignment only — it does not guarantee
    ATS success.
  </span>
);
const TIP_QUALITY = (
  <span>
    50% section completeness (8 expected sections) + 50% content depth: contact info, summary length, bullet usage,
    quantified achievements, action verbs and word count.
  </span>
);
const TIP_SKILLS = (
  <span>Share of the job description's required skills (from a 60+ skill dictionary) that also appear in your resume.</span>
);
const TIP_KEYWORDS = (
  <span>Rank-weighted coverage of the job description's most important terms. Missing terms are listed below — only add ones that genuinely reflect your experience.</span>
);

export default function ScoreGauges({ data }: { data: AnalysisResponse }) {
  const isJob = data.meta.mode === 'job_match';
  const cards = [
    { label: 'Overall Match', value: data.overall_score, tip: TIP_OVERALL },
    { label: 'Resume Quality', value: data.resume_quality_score, tip: TIP_QUALITY },
    {
      label: isJob ? 'Skills Match' : 'Skill Breadth',
      value: data.skills_match_score,
      tip: isJob ? TIP_SKILLS : <span>No JD provided — this rates the breadth of your detected skill profile instead.</span>,
    },
    {
      label: isJob ? 'Keyword Match' : 'Keyword Richness',
      value: data.keyword_match_score,
      tip: isJob ? TIP_KEYWORDS : <span>No JD provided — this rates vocabulary depth and specificity in your resume.</span>,
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {cards.map((c) => (
        <GlassCard key={c.label} className="flex flex-col items-center px-4 py-7">
          <Gauge value={c.value} label={c.label} />
          <span className="mt-1 flex items-center gap-1 text-xs text-slate-400 dark:text-slate-500">
            How is this computed? <Tooltip content={c.tip} wide />
          </span>
        </GlassCard>
      ))}
    </div>
  );
}
