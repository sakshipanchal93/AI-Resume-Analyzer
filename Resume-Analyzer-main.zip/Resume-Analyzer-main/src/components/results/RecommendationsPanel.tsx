import { motion } from 'framer-motion';
import { Lightbulb } from 'lucide-react';
import { GlassCard, PriorityBadge } from '../ui';
import type { AnalysisResponse } from '../../lib/types';

export default function RecommendationsPanel({ data }: { data: AnalysisResponse }) {
  return (
    <GlassCard className="p-6">
      <div className="flex items-center gap-2.5">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500/10 text-amber-500 dark:text-amber-400">
          <Lightbulb size={18} />
        </span>
        <div>
          <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Actionable Recommendations</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Generated dynamically from your analysis — highest impact first.
          </p>
        </div>
      </div>
      <ol className="mt-5 space-y-3">
        {data.recommendations.map((r, i) => (
          <motion.li
            key={r.title}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.06 * i, duration: 0.35 }}
            className="flex items-start gap-3.5 rounded-xl border border-slate-200/70 bg-white/50 p-4 dark:border-white/[0.07] dark:bg-white/[0.02]"
          >
            <span className="font-display mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-indigo-500 text-[11px] font-bold text-white">
              {i + 1}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{r.title}</p>
                <PriorityBadge priority={r.priority} />
              </div>
              <p className="mt-1 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{r.detail}</p>
            </div>
          </motion.li>
        ))}
      </ol>
    </GlassCard>
  );
}
