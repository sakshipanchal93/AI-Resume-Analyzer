import { motion } from 'framer-motion';
import { scoreTone } from './ui';

interface GaugeProps {
  value: number | null;
  label: string;
  size?: number;
  stroke?: number;
}

/** Animated circular progress indicator. */
export default function Gauge({ value, label, size = 140, stroke = 11 }: GaugeProps) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const target = value === null ? 0 : (Math.max(0, Math.min(100, value)) / 100) * c;
  const tone = scoreTone(value);
  const gid = `g-${label.replace(/\W+/g, '-')}`;

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <defs>
            <linearGradient id={gid} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={tone.gradient[0]} />
              <stop offset="100%" stopColor={tone.gradient[1]} />
            </linearGradient>
          </defs>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} className="stroke-slate-200 dark:stroke-white/[0.07]" />
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            strokeWidth={stroke}
            strokeLinecap="round"
            stroke={value === null ? undefined : `url(#${gid})`}
            className={value === null ? 'stroke-slate-300 dark:stroke-slate-700' : ''}
            strokeDasharray={c}
            initial={{ strokeDashoffset: c }}
            animate={{ strokeDashoffset: c - target }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 0.15 }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className={`font-display text-3xl font-bold tabular-nums ${tone.text}`}
          >
            {value === null ? 'N/A' : value}
          </motion.span>
          {value !== null && <span className="text-[10px] font-semibold tracking-widest text-slate-400 uppercase dark:text-slate-500">/ 100</span>}
        </div>
      </div>
      <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{label}</p>
    </div>
  );
}
