resume_text = """Aarav Sharma
Bengaluru, India
aarav.sharma@email.com | +91 98765 43210 | linkedin.com/in/aaravsharma | github.com/aaravsharma

PROFESSIONAL SUMMARY
Full-stack software engineer with 5+ years of experience building scalable web applications and data-driven services. Strong background in React, TypeScript, Node.js and Python, deploying cloud-native systems on AWS.

TECHNICAL SKILLS
Languages: Python, JavaScript, TypeScript, SQL
Frontend: React, Redux, HTML, CSS, Tailwind CSS
Backend: Node.js, Express, FastAPI, REST API, Microservices
Databases: PostgreSQL, MongoDB, Redis
Cloud & DevOps: AWS, Docker, CI/CD, GitHub Actions, Linux, Git, GitHub
Data: Pandas, NumPy, Scikit-Learn, Machine Learning

PROFESSIONAL EXPERIENCE
Senior Software Engineer, FinEdge Technologies, Bengaluru
2021 - Present
- Designed and shipped a React and TypeScript analytics dashboard used by 40,000 monthly active users, improving report load time by 62%.
- Built FastAPI microservices on AWS with PostgreSQL, processing 2M transactions daily at 99.95% uptime.
- Led migration to a microservices architecture, reducing deployment time from 2 hours to 15 minutes using Docker and CI/CD pipelines.

Software Engineer, CloudKart Solutions
2019 - 2021
- Developed Node.js and Express REST APIs powering a marketplace with 120,000 users.
- Optimized PostgreSQL queries and Redis caching, cutting p95 API latency by 45%.

PROJECTS
ResumeMatch, NLP-based resume screening tool (Python, Scikit-Learn, FastAPI, React) reaching 88% precision.
DevBoard, developer productivity dashboard (Next.js, PostgreSQL, Docker) adopted by 30 internal teams.

EDUCATION
B.E. in Computer Science, Visvesvaraya Technological University
2015 - 2019, CGPA 8.7/10

CERTIFICATIONS
AWS Certified Solutions Architect Associate (2023)
MongoDB Certified Developer (2022)

ACHIEVEMENTS
Won the company hackathon 2022 (1st place among 42 teams) for an ML-based fraud-detection prototype.
"""

# TXT
with open("scripts/fixtures/resume.txt", "w") as f:
    f.write(resume_text)

# PDF via PyMuPDF
import fitz
doc = fitz.open()
page = doc.new_page()
y = 60
for line in resume_text.split("\n"):
    page.insert_text((50, y), line, fontsize=9)
    y += 13
    if y > 780:
        page = doc.new_page()
        y = 60
doc.save("scripts/fixtures/resume.pdf")
doc.close()

# DOCX via python-docx
from docx import Document
d = Document()
for line in resume_text.split("\n"):
    d.add_paragraph(line)
d.save("scripts/fixtures/resume.docx")

print("fixtures created")
