// End-to-end test of the /api/analyze serverless handler with real multipart bodies.
import { Readable } from 'node:stream';
import { readFileSync } from 'node:fs';
import assert from 'node:assert';
import handler from '../api/analyze.js';

const JD = `Senior Software Engineer. Responsibilities: develop microservices and REST API GraphQL endpoints in TypeScript and Node.js. Build frontends with React, TypeScript and Tailwind CSS. Deploy with Docker and Kubernetes on AWS. Unit testing with Jest, CI/CD automation. Requirements: 4+ years of software engineering experience with TypeScript, React and Node.js. Solid PostgreSQL, Redis and Kafka knowledge. Hands-on production experience with AWS, Docker and Kubernetes. Understanding of microservices, distributed systems and observability.`;

function makeReq(bodyBuffer, boundary, method = 'POST') {
  const req = Readable.from(bodyBuffer);
  req.headers = { 'content-type': `multipart/form-data; boundary=${boundary}` };
  req.method = method;
  return req;
}
function makeRes() {
  return {
    statusCode: 200, headers: {}, body: undefined,
    setHeader(k, v) { this.headers[k] = v; },
    status(c) { this.statusCode = c; return this; },
    json(d) { this.body = d; return this; },
    end() { return this; },
  };
}
async function callApi(filePath, jd, extra = {}, method = 'POST', omitFile = false) {
  const boundary = '----alignai-test-' + Date.now();
  const parts = [];
  const field = (n, v) => Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${n}"\r\n\r\n${v}\r\n`);
  parts.push(field('job_description', jd));
  for (const [k, v] of Object.entries(extra)) parts.push(field(k, v));
  if (!omitFile) {
    const file = readFileSync(filePath);
    const name = filePath.split('/').pop();
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="resume"; filename="${name}"\r\nContent-Type: application/octet-stream\r\n\r\n`));
    parts.push(file);
    parts.push(Buffer.from('\r\n'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`));
  const res = makeRes();
  await handler(makeReq(Buffer.concat(parts), boundary, method), res);
  return res;
}

let pass = 0;
const ok = (cond, msg) => { assert(cond, msg); pass += 1; console.log('  ✓', msg); };

for (const f of ['scripts/fixtures/resume.txt', 'scripts/fixtures/resume.pdf', 'scripts/fixtures/resume.docx']) {
  console.log(`\n[upload] ${f}`);
  const res = await callApi(f, JD, { demo: 'true' });
  ok(res.statusCode === 200, `HTTP 200 (got ${res.statusCode}: ${JSON.stringify(res.body).slice(0, 120)})`);
  const b = res.body;
  ok(typeof b.overall_score === 'number' && b.overall_score > 0, `overall_score = ${b.overall_score}`);
  ok(b.meta.mode === 'job_match' && b.meta.demo === true, `meta: mode=${b.meta.mode} demo=${b.meta.demo}`);
  ok(b.matched_skills.includes('React') && b.matched_skills.includes('Docker'), `matched skills include React+Docker`);
  ok(b.missing_skills.includes('Kubernetes') && b.missing_skills.includes('GraphQL'), 'missing skills include Kubernetes+GraphQL');
  ok(b.sections.length === 8, '8 sections audited');
  ok(b.recommendations.length >= 3, `${b.recommendations.length} recommendations`);
}

console.log('\n[parsers produce consistent results across formats]');
const [txt, pdf, docx] = [];
const rTxt = (await callApi('scripts/fixtures/resume.txt', JD)).body;
const rPdf = (await callApi('scripts/fixtures/resume.pdf', JD)).body;
const rDocx = (await callApi('scripts/fixtures/resume.docx', JD)).body;
ok(Math.abs(rPdf.overall_score - rTxt.overall_score) <= 6, `PDF overall ${rPdf.overall_score} ≈ TXT ${rTxt.overall_score}`);
ok(Math.abs(rDocx.overall_score - rTxt.overall_score) <= 6, `DOCX overall ${rDocx.overall_score} ≈ TXT ${rTxt.overall_score}`);
ok(rPdf.skills.length >= 12 && rDocx.skills.length >= 12, `PDF ${rPdf.skills.length} skills, DOCX ${rDocx.skills.length} skills`);

console.log('\n[error handling]');
let res = await callApi('scripts/fixtures/resume.txt', JD, {}, 'GET');
ok(res.statusCode === 405, `GET -> 405`);
res = await callApi('scripts/fixtures/resume.txt', JD, {}, 'POST', true);
ok(res.statusCode === 400, `missing file -> 400 (${res.body.error.slice(0, 40)}…)`);
// wrong extension
{
  const boundary = '----b' + Date.now();
  const png = readFileSync('scripts/fixtures/resume.txt');
  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="resume"; filename="photo.png"\r\nContent-Type: image/png\r\n\r\n`),
    png,
    Buffer.from(`\r\n--${boundary}--\r\n`),
  ]);
  const r = makeRes();
  await handler(makeReq(body, boundary), r);
  ok(r.statusCode === 415, `png upload -> 415`);
}
// tiny/invalid resume
{
  const boundary = '----b' + Date.now();
  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="resume"; filename="tiny.txt"\r\nContent-Type: text/plain\r\n\r\nhi there\r\n--${boundary}--\r\n`),
  ]);
  const r = makeRes();
  await handler(makeReq(body, boundary), r);
  ok(r.statusCode === 422, `2-word resume -> 422 (${r.body.error.slice(0, 44)}…)`);
}
// resume-only mode
res = await callApi('scripts/fixtures/resume.txt', '');
ok(res.statusCode === 200 && res.body.meta.mode === 'quality', 'resume-only -> mode=quality, HTTP 200');
console.log(`\nAll ${pass} API assertions passed ✅`);
