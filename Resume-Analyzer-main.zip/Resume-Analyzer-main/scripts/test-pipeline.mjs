// Offline smoke test for the analysis pipeline (Node implementation).
// Run: node scripts/test-pipeline.mjs
import assert from 'node:assert';
import { analyzeResumeText } from '../api/lib/analyzer.js';
import { extractSkills } from '../api/lib/skills.js';
import { canonicalize, tokenize } from '../api/lib/text.js';
import { tfidfCosine } from '../api/lib/similarity.js';

const RESUME = `Aarav Sharma
Bengaluru, India
aarav.sharma@email.com | +91 98765 43210 | linkedin.com/in/aaravsharma | github.com/aaravsharma

PROFESSIONAL SUMMARY
Full-stack software engineer with 5+ years of experience building scalable web applications and data-driven services. Strong background in React, TypeScript, Node.js and Python, deploying cloud-native systems on AWS.

TECHNICAL SKILLS
Languages: Python, JavaScript, TypeScript, SQL
Frontend: React, Redux, HTML, CSS, Tailwind CSS
Backend: Node.js, Express, FastAPI, REST API, Microservices
Databases: PostgreSQL, MongoDB, Redis
Cloud & DevOps: AWS, Docker, CI/CD, GitHub Actions, Linux, Git, GitHub
Data: Pandas, NumPy, Scikit-Learn, Machine Learning

PROFESSIONAL EXPERIENCE
Senior Software Engineer, FinEdge Technologies, Bengaluru
2021 - Present
- Designed and shipped a React and TypeScript analytics dashboard used by 40,000 monthly active users, improving report load time by 62%.
- Built FastAPI microservices on AWS with PostgreSQL, processing 2M transactions daily at 99.95% uptime.
- Led migration to a microservices architecture, reducing deployment time from 2 hours to 15 minutes using Docker and CI/CD pipelines.
- Mentored 4 junior engineers and introduced automated testing practices that raised coverage from 38% to 85%.

Software Engineer, CloudKart Solutions
2019 - 2021
- Developed Node.js and Express REST APIs powering a marketplace with 120,000 users.
- Optimized PostgreSQL queries and Redis caching, cutting p95 API latency by 45%.
- Implemented a real-time notification service using WebSockets and MongoDB for 30,000 daily orders.

PROJECTS
ResumeMatch, NLP-based resume screening tool (Python, Scikit-Learn, FastAPI, React). TF-IDF similarity ranking with skill extraction, reaching 88% precision on labeled evaluation data.
DevBoard, developer productivity dashboard (Next.js, PostgreSQL, Docker) adopted by 30 internal teams.

EDUCATION
B.E. in Computer Science, Visvesvaraya Technological University
2015 - 2019, CGPA 8.7/10

CERTIFICATIONS
AWS Certified Solutions Architect Associate (2023)
MongoDB Certified Developer (2022)

ACHIEVEMENTS
Won the company hackathon 2022 (1st place among 42 teams) for an ML-based fraud-detection prototype.
Speaker at BengaluruJS meetup on React performance optimization (150 attendees).
`;

const JD = `Senior Software Engineer, Payments Platform
We are looking for a Senior Software Engineer to join our payments team. You will design, build and operate large-scale distributed services.
Responsibilities:
- Design and develop microservices and REST API GraphQL endpoints in TypeScript and Node.js.
- Build rich, accessible frontends with React, TypeScript and Tailwind CSS.
- Deploy containerized workloads with Docker and Kubernetes on AWS.
- Own quality through unit testing with Jest and CI/CD automation.
- Collaborate in an Agile environment; lead system design discussions.
Requirements:
- 4+ years of professional software engineering experience with TypeScript, React and Node.js.
- Solid PostgreSQL knowledge; familiarity with Redis and Kafka.
- Hands-on production experience with AWS, Docker and Kubernetes.
- Understanding of microservices, distributed systems and observability.`;

let pass = 0;
const ok = (cond, msg) => { assert(cond, msg); pass += 1; console.log('  ✓', msg); };

console.log('\n[1] canonicalization & tokenization');
ok(canonicalize('C++ and C# with Node.js, CI/CD and Scikit-Learn').includes('cplusplus'), 'c++ -> cplusplus');
ok(canonicalize('C++ and C# with Node.js, CI/CD and Scikit-Learn').includes('csharp'), 'c# -> csharp');
ok(canonicalize('C++ and C# with Node.js, CI/CD and Scikit-Learn').includes('nodejs'), 'node.js -> nodejs');
ok(canonicalize('C++ and C# with Node.js, CI/CD and Scikit-Learn').includes('cicd'), 'ci/cd -> cicd');
ok(canonicalize('C++ and C# with Node.js, CI/CD and Scikit-Learn').includes('scikitlearn'), 'scikit-learn -> scikitlearn');
ok(!tokenize('the and of for with').length, 'stopwords removed');

console.log('\n[2] skill extraction');
const skills = extractSkills(RESUME).map(s => s.name);
for (const expected of ['Python', 'React', 'Node.js', 'PostgreSQL', 'AWS', 'Docker', 'Scikit-Learn', 'Tailwind CSS', 'TypeScript', 'CI/CD'])
  ok(skills.includes(expected), `found ${expected}`);
ok(!extractSkills('I love baking bread and hiking.').some(s => s.name === 'Kubernetes'), 'no false positive');

console.log('\n[3] TF-IDF cosine similarity');
const sim = tfidfCosine(RESUME, JD);
ok(sim > 0.1 && sim <= 1, `resume/JD similarity = ${sim.toFixed(3)} (in range)`);
ok(Math.abs(tfidfCosine('python pandas numpy', 'python pandas numpy') - 1) < 1e-6, 'identical docs -> 1.0');
ok(tfidfCosine('', JD) === 0, 'empty doc -> 0');

console.log('\n[4] full analysis — job match mode');
const r = analyzeResumeText({ resumeText: RESUME, jdText: JD, fileName: 'resume.txt', fileType: 'txt' });
ok(r.meta.mode === 'job_match', 'mode = job_match');
ok(r.overall_score >= 0 && r.overall_score <= 100, `overall_score = ${r.overall_score}`);
ok(r.resume_quality_score >= 60, `quality = ${r.resume_quality_score} (rich resume)`);
ok(r.matched_skills.length >= 8, `matched ${r.matched_skills.length} skills: ${r.matched_skills.join(', ')}`);
ok(r.missing_skills.includes('Kubernetes'), 'detected missing skill: Kubernetes');
ok(r.missing_skills.includes('GraphQL'), 'detected missing skill: GraphQL');
ok(r.skill_match_ratio && r.skill_match_ratio.required > 0, `ratio ${r.skill_match_ratio.matched}/${r.skill_match_ratio.required}`);
ok(r.keywords.length + r.missing_keywords.length === r.jd_keywords.length, 'keyword partition consistent');
ok(r.jd_keywords.length >= 8, `${r.jd_keywords.length} JD keywords extracted`);
ok(r.sections.length === 8, '8 sections audited');
ok(r.sections.every(s => s.status === 'present'), 'all sections present in strong resume');
ok(r.completeness_score === 100, `completeness = ${r.completeness_score}%`);
ok(r.metrics.quantified_achievements >= 3, `${r.metrics.quantified_achievements} quantified achievements`);
ok(r.recommendations.length >= 2 && r.recommendations.length <= 7, `${r.recommendations.length} recommendations`);
ok(r.summary.includes(String(r.overall_score)), 'summary mentions the overall score');
ok(r.charts.radar.length === 6 && r.charts.skill_distribution.length >= 3, 'chart payloads present');
ok(r.weights.reduce((a, w) => a + w.value, 0) === 100, 'weights sum to 100');

console.log('\n[5] full analysis — resume-only mode');
const r2 = analyzeResumeText({ resumeText: RESUME, jdText: '', fileName: 'resume.txt', fileType: 'txt' });
ok(r2.meta.mode === 'quality', 'mode = quality');
ok(r2.similarity_score === null, 'no similarity without JD');
ok(r2.keyword_match_score !== null && r2.skills_match_score !== null, 'breadth/richness scores present');
ok(r2.resume_top_keywords.length > 0, 'top resume keywords present');

console.log('\n[6] weak resume handled gracefully');
const WEAK = 'John\n\nI worked at a shop. I like computers and I am good with people. Contact me for more info please thank you very much indeed.';
const r3 = analyzeResumeText({ resumeText: WEAK, jdText: JD, fileName: 'weak.txt', fileType: 'txt' });
ok(r3.sections.some(s => s.status === 'missing'), 'missing sections detected on weak resume');
ok(r3.resume_quality_score < r.resume_quality_score, `weak (${r3.resume_quality_score}) < strong (${r.resume_quality_score})`);
ok(r3.recommendations.some(r4 => r4.priority === 'high'), 'high-priority recommendations generated');

console.log(`\nAll ${pass} assertions passed ✅\n`);
